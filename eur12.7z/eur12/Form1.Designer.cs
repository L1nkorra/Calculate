﻿namespace eur12
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.RSU_panel = new System.Windows.Forms.Panel();
            this.panelparameters = new System.Windows.Forms.Panel();
            this.FuncTCombobox = new System.Windows.Forms.ComboBox();
            this.step_tNUD = new System.Windows.Forms.NumericUpDown();
            this.T_0NUD = new System.Windows.Forms.NumericUpDown();
            this.t_TNUD = new System.Windows.Forms.NumericUpDown();
            this.WeightNUD = new System.Windows.Forms.NumericUpDown();
            this.HeightNUD = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.parametersbut = new System.Windows.Forms.Button();
            this.tavr_panel = new System.Windows.Forms.Panel();
            this.tavrupsidescheck = new System.Windows.Forms.CheckBox();
            this.tavrallsidescheck = new System.Windows.Forms.CheckBox();
            this.tavrdownsidescheck = new System.Windows.Forms.CheckBox();
            this.quadrant_panel = new System.Windows.Forms.Panel();
            this.Quadrantdownsidecheck = new System.Windows.Forms.CheckBox();
            this.Quadrantupsidecheck = new System.Windows.Forms.CheckBox();
            this.Quadrantrightsidecheck = new System.Windows.Forms.CheckBox();
            this.Quadrantleftsidecheck = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.A700choice = new System.Windows.Forms.ComboBox();
            this.A600choice = new System.Windows.Forms.ComboBox();
            this.A500choice = new System.Windows.Forms.ComboBox();
            this.label_arm = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Armaturecombobox = new System.Windows.Forms.ComboBox();
            this.WvalueNUD = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.betonRoNUD = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.carbonated_concrete_check = new System.Windows.Forms.RadioButton();
            this.silicate_concrete_check = new System.Windows.Forms.RadioButton();
            this.fire_resist_checkbox = new System.Windows.Forms.CheckBox();
            this.fire_safety_checkbox = new System.Windows.Forms.CheckBox();
            this.TopMenuStrip = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.инструкцияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.помощьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.acceptinputbutton = new System.Windows.Forms.Button();
            this.Calculatebutton = new System.Windows.Forms.Button();
            this.RSU_panel.SuspendLayout();
            this.panelparameters.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.step_tNUD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.T_0NUD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t_TNUD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WeightNUD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HeightNUD)).BeginInit();
            this.tavr_panel.SuspendLayout();
            this.quadrant_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.WvalueNUD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.betonRoNUD)).BeginInit();
            this.TopMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // RSU_panel
            // 
            this.RSU_panel.Controls.Add(this.Calculatebutton);
            this.RSU_panel.Controls.Add(this.acceptinputbutton);
            this.RSU_panel.Controls.Add(this.panelparameters);
            this.RSU_panel.Controls.Add(this.parametersbut);
            this.RSU_panel.Controls.Add(this.tavr_panel);
            this.RSU_panel.Controls.Add(this.quadrant_panel);
            this.RSU_panel.Controls.Add(this.label6);
            this.RSU_panel.Controls.Add(this.A700choice);
            this.RSU_panel.Controls.Add(this.A600choice);
            this.RSU_panel.Controls.Add(this.A500choice);
            this.RSU_panel.Controls.Add(this.label_arm);
            this.RSU_panel.Controls.Add(this.label3);
            this.RSU_panel.Controls.Add(this.Armaturecombobox);
            this.RSU_panel.Controls.Add(this.WvalueNUD);
            this.RSU_panel.Controls.Add(this.label5);
            this.RSU_panel.Controls.Add(this.betonRoNUD);
            this.RSU_panel.Controls.Add(this.label4);
            this.RSU_panel.Controls.Add(this.label2);
            this.RSU_panel.Controls.Add(this.label1);
            this.RSU_panel.Controls.Add(this.carbonated_concrete_check);
            this.RSU_panel.Controls.Add(this.silicate_concrete_check);
            this.RSU_panel.Controls.Add(this.fire_resist_checkbox);
            this.RSU_panel.Controls.Add(this.fire_safety_checkbox);
            this.RSU_panel.Location = new System.Drawing.Point(0, 27);
            this.RSU_panel.Name = "RSU_panel";
            this.RSU_panel.Size = new System.Drawing.Size(620, 411);
            this.RSU_panel.TabIndex = 0;
            // 
            // panelparameters
            // 
            this.panelparameters.Controls.Add(this.FuncTCombobox);
            this.panelparameters.Controls.Add(this.step_tNUD);
            this.panelparameters.Controls.Add(this.T_0NUD);
            this.panelparameters.Controls.Add(this.t_TNUD);
            this.panelparameters.Controls.Add(this.WeightNUD);
            this.panelparameters.Controls.Add(this.HeightNUD);
            this.panelparameters.Controls.Add(this.label13);
            this.panelparameters.Controls.Add(this.label12);
            this.panelparameters.Controls.Add(this.label11);
            this.panelparameters.Controls.Add(this.label10);
            this.panelparameters.Controls.Add(this.label9);
            this.panelparameters.Controls.Add(this.label8);
            this.panelparameters.Controls.Add(this.label7);
            this.panelparameters.Location = new System.Drawing.Point(16, 131);
            this.panelparameters.Name = "panelparameters";
            this.panelparameters.Size = new System.Drawing.Size(373, 189);
            this.panelparameters.TabIndex = 22;
            this.panelparameters.Visible = false;
            // 
            // FuncTCombobox
            // 
            this.FuncTCombobox.FormattingEnabled = true;
            this.FuncTCombobox.Items.AddRange(new object[] {
            "Стандартный пожар (ГОСТ 30247.0-94)",
            "Задать таблицу (функция должна быть неубывающей)"});
            this.FuncTCombobox.Location = new System.Drawing.Point(223, 140);
            this.FuncTCombobox.Name = "FuncTCombobox";
            this.FuncTCombobox.Size = new System.Drawing.Size(121, 21);
            this.FuncTCombobox.TabIndex = 23;
            // 
            // step_tNUD
            // 
            this.step_tNUD.DecimalPlaces = 1;
            this.step_tNUD.Location = new System.Drawing.Point(222, 112);
            this.step_tNUD.Name = "step_tNUD";
            this.step_tNUD.Size = new System.Drawing.Size(122, 22);
            this.step_tNUD.TabIndex = 32;
            // 
            // T_0NUD
            // 
            this.T_0NUD.DecimalPlaces = 1;
            this.T_0NUD.Location = new System.Drawing.Point(222, 88);
            this.T_0NUD.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.T_0NUD.Name = "T_0NUD";
            this.T_0NUD.Size = new System.Drawing.Size(122, 22);
            this.T_0NUD.TabIndex = 31;
            this.T_0NUD.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // t_TNUD
            // 
            this.t_TNUD.DecimalPlaces = 1;
            this.t_TNUD.Location = new System.Drawing.Point(222, 60);
            this.t_TNUD.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.t_TNUD.Name = "t_TNUD";
            this.t_TNUD.Size = new System.Drawing.Size(122, 22);
            this.t_TNUD.TabIndex = 30;
            this.t_TNUD.Value = new decimal(new int[] {
            90,
            0,
            0,
            0});
            // 
            // WeightNUD
            // 
            this.WeightNUD.DecimalPlaces = 1;
            this.WeightNUD.Location = new System.Drawing.Point(222, 32);
            this.WeightNUD.Name = "WeightNUD";
            this.WeightNUD.Size = new System.Drawing.Size(122, 22);
            this.WeightNUD.TabIndex = 29;
            // 
            // HeightNUD
            // 
            this.HeightNUD.DecimalPlaces = 1;
            this.HeightNUD.Location = new System.Drawing.Point(222, 6);
            this.HeightNUD.Name = "HeightNUD";
            this.HeightNUD.Size = new System.Drawing.Size(122, 22);
            this.HeightNUD.TabIndex = 23;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 163);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(72, 13);
            this.label13.TabIndex = 28;
            this.label13.Text = "Что-то ещё?";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 144);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(214, 13);
            this.label12.TabIndex = 27;
            this.label12.Text = "Зависимость температуры от времени";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 114);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(177, 13);
            this.label11.TabIndex = 26;
            this.label11.Text = "Шаг изменения температуры, С";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 88);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(149, 13);
            this.label10.TabIndex = 25;
            this.label10.Text = "Начальная температура, С";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 60);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(154, 13);
            this.label9.TabIndex = 24;
            this.label9.Text = "Длительность пожара, мин";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 32);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 13);
            this.label8.TabIndex = 24;
            this.label8.Text = "Ширина, м";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 6);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "Высота, м";
            // 
            // parametersbut
            // 
            this.parametersbut.Location = new System.Drawing.Point(16, 102);
            this.parametersbut.Name = "parametersbut";
            this.parametersbut.Size = new System.Drawing.Size(204, 23);
            this.parametersbut.TabIndex = 22;
            this.parametersbut.Text = "Ввод дополнительных параметров";
            this.parametersbut.UseVisualStyleBackColor = true;
            this.parametersbut.Click += new System.EventHandler(this.parametersbut_Click);
            // 
            // tavr_panel
            // 
            this.tavr_panel.Controls.Add(this.tavrupsidescheck);
            this.tavr_panel.Controls.Add(this.tavrallsidescheck);
            this.tavr_panel.Controls.Add(this.tavrdownsidescheck);
            this.tavr_panel.Location = new System.Drawing.Point(486, 308);
            this.tavr_panel.Name = "tavr_panel";
            this.tavr_panel.Size = new System.Drawing.Size(84, 100);
            this.tavr_panel.TabIndex = 21;
            // 
            // tavrupsidescheck
            // 
            this.tavrupsidescheck.AutoSize = true;
            this.tavrupsidescheck.Checked = true;
            this.tavrupsidescheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tavrupsidescheck.Location = new System.Drawing.Point(3, 4);
            this.tavrupsidescheck.Name = "tavrupsidescheck";
            this.tavrupsidescheck.Size = new System.Drawing.Size(58, 17);
            this.tavrupsidescheck.TabIndex = 4;
            this.tavrupsidescheck.Text = "Левая";
            this.tavrupsidescheck.UseVisualStyleBackColor = true;
            // 
            // tavrallsidescheck
            // 
            this.tavrallsidescheck.AutoSize = true;
            this.tavrallsidescheck.Checked = true;
            this.tavrallsidescheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tavrallsidescheck.Location = new System.Drawing.Point(3, 50);
            this.tavrallsidescheck.Name = "tavrallsidescheck";
            this.tavrallsidescheck.Size = new System.Drawing.Size(71, 17);
            this.tavrallsidescheck.TabIndex = 6;
            this.tavrallsidescheck.Text = "Верхняя";
            this.tavrallsidescheck.UseVisualStyleBackColor = true;
            // 
            // tavrdownsidescheck
            // 
            this.tavrdownsidescheck.AutoSize = true;
            this.tavrdownsidescheck.Checked = true;
            this.tavrdownsidescheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tavrdownsidescheck.Location = new System.Drawing.Point(3, 27);
            this.tavrdownsidescheck.Name = "tavrdownsidescheck";
            this.tavrdownsidescheck.Size = new System.Drawing.Size(65, 17);
            this.tavrdownsidescheck.TabIndex = 5;
            this.tavrdownsidescheck.Text = "Правая";
            this.tavrdownsidescheck.UseVisualStyleBackColor = true;
            // 
            // quadrant_panel
            // 
            this.quadrant_panel.Controls.Add(this.Quadrantdownsidecheck);
            this.quadrant_panel.Controls.Add(this.Quadrantupsidecheck);
            this.quadrant_panel.Controls.Add(this.Quadrantrightsidecheck);
            this.quadrant_panel.Controls.Add(this.Quadrantleftsidecheck);
            this.quadrant_panel.Location = new System.Drawing.Point(395, 308);
            this.quadrant_panel.Name = "quadrant_panel";
            this.quadrant_panel.Size = new System.Drawing.Size(85, 100);
            this.quadrant_panel.TabIndex = 20;
            // 
            // Quadrantdownsidecheck
            // 
            this.Quadrantdownsidecheck.AutoSize = true;
            this.Quadrantdownsidecheck.Checked = true;
            this.Quadrantdownsidecheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Quadrantdownsidecheck.Location = new System.Drawing.Point(4, 73);
            this.Quadrantdownsidecheck.Name = "Quadrantdownsidecheck";
            this.Quadrantdownsidecheck.Size = new System.Drawing.Size(69, 17);
            this.Quadrantdownsidecheck.TabIndex = 3;
            this.Quadrantdownsidecheck.Text = "Нижняя";
            this.Quadrantdownsidecheck.UseVisualStyleBackColor = true;
            // 
            // Quadrantupsidecheck
            // 
            this.Quadrantupsidecheck.AutoSize = true;
            this.Quadrantupsidecheck.Checked = true;
            this.Quadrantupsidecheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Quadrantupsidecheck.Location = new System.Drawing.Point(4, 50);
            this.Quadrantupsidecheck.Name = "Quadrantupsidecheck";
            this.Quadrantupsidecheck.Size = new System.Drawing.Size(71, 17);
            this.Quadrantupsidecheck.TabIndex = 2;
            this.Quadrantupsidecheck.Text = "Верхняя";
            this.Quadrantupsidecheck.UseVisualStyleBackColor = true;
            // 
            // Quadrantrightsidecheck
            // 
            this.Quadrantrightsidecheck.AutoSize = true;
            this.Quadrantrightsidecheck.Checked = true;
            this.Quadrantrightsidecheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Quadrantrightsidecheck.Location = new System.Drawing.Point(4, 27);
            this.Quadrantrightsidecheck.Name = "Quadrantrightsidecheck";
            this.Quadrantrightsidecheck.Size = new System.Drawing.Size(65, 17);
            this.Quadrantrightsidecheck.TabIndex = 1;
            this.Quadrantrightsidecheck.Text = "Правая";
            this.Quadrantrightsidecheck.UseVisualStyleBackColor = true;
            // 
            // Quadrantleftsidecheck
            // 
            this.Quadrantleftsidecheck.AutoSize = true;
            this.Quadrantleftsidecheck.Checked = true;
            this.Quadrantleftsidecheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Quadrantleftsidecheck.Location = new System.Drawing.Point(4, 4);
            this.Quadrantleftsidecheck.Name = "Quadrantleftsidecheck";
            this.Quadrantleftsidecheck.Size = new System.Drawing.Size(58, 17);
            this.Quadrantleftsidecheck.TabIndex = 0;
            this.Quadrantleftsidecheck.Text = "Левая";
            this.Quadrantleftsidecheck.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(392, 289);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(191, 13);
            this.label6.TabIndex = 18;
            this.label6.Text = "Количество обогреваемых сторон";
            // 
            // A700choice
            // 
            this.A700choice.FormattingEnabled = true;
            this.A700choice.Items.AddRange(new object[] {
            "Б500",
            "Б500С марки Ст3Гпс"});
            this.A700choice.Location = new System.Drawing.Point(157, 74);
            this.A700choice.Name = "A700choice";
            this.A700choice.Size = new System.Drawing.Size(136, 21);
            this.A700choice.TabIndex = 17;
            this.A700choice.Visible = false;
            // 
            // A600choice
            // 
            this.A600choice.FormattingEnabled = true;
            this.A600choice.Items.AddRange(new object[] {
            "А600",
            "А600С марки 18Г2СФ"});
            this.A600choice.Location = new System.Drawing.Point(153, 74);
            this.A600choice.Name = "A600choice";
            this.A600choice.Size = new System.Drawing.Size(136, 21);
            this.A600choice.TabIndex = 16;
            this.A600choice.Visible = false;
            // 
            // A500choice
            // 
            this.A500choice.FormattingEnabled = true;
            this.A500choice.Items.AddRange(new object[] {
            "А500",
            "А500С марки 25Г2С",
            "А500С марки Ст3Гпс"});
            this.A500choice.Location = new System.Drawing.Point(148, 74);
            this.A500choice.Name = "A500choice";
            this.A500choice.Size = new System.Drawing.Size(136, 21);
            this.A500choice.TabIndex = 15;
            this.A500choice.Visible = false;
            // 
            // label_arm
            // 
            this.label_arm.AutoSize = true;
            this.label_arm.Location = new System.Drawing.Point(158, 58);
            this.label_arm.Name = "label_arm";
            this.label_arm.Size = new System.Drawing.Size(96, 13);
            this.label_arm.TabIndex = 14;
            this.label_arm.Text = "Уточнение стали";
            this.label_arm.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Выбор арматуры";
            // 
            // Armaturecombobox
            // 
            this.Armaturecombobox.FormattingEnabled = true;
            this.Armaturecombobox.Items.AddRange(new object[] {
            "А500",
            "А600",
            "B500"});
            this.Armaturecombobox.Location = new System.Drawing.Point(16, 74);
            this.Armaturecombobox.Name = "Armaturecombobox";
            this.Armaturecombobox.Size = new System.Drawing.Size(121, 21);
            this.Armaturecombobox.TabIndex = 12;
            this.Armaturecombobox.SelectedIndexChanged += new System.EventHandler(this.Armaturecombobox_SelectedIndexChanged);
            // 
            // WvalueNUD
            // 
            this.WvalueNUD.DecimalPlaces = 2;
            this.WvalueNUD.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.WvalueNUD.Location = new System.Drawing.Point(306, 34);
            this.WvalueNUD.Name = "WvalueNUD";
            this.WvalueNUD.Size = new System.Drawing.Size(122, 22);
            this.WvalueNUD.TabIndex = 10;
            this.WvalueNUD.Value = new decimal(new int[] {
            75,
            0,
            0,
            131072});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(287, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Весовая эксплуатационная влажность бетона W, %  ";
            // 
            // betonRoNUD
            // 
            this.betonRoNUD.DecimalPlaces = 1;
            this.betonRoNUD.Location = new System.Drawing.Point(306, 6);
            this.betonRoNUD.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.betonRoNUD.Name = "betonRoNUD";
            this.betonRoNUD.Size = new System.Drawing.Size(122, 22);
            this.betonRoNUD.TabIndex = 8;
            this.betonRoNUD.Value = new decimal(new int[] {
            22,
            0,
            0,
            65536});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(185, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Плотность сухого бетона ρ, т/м3 ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(219, 337);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Выбор заполнителя бетона";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 337);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(146, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Дополнительные условия";
            // 
            // carbonated_concrete_check
            // 
            this.carbonated_concrete_check.AutoSize = true;
            this.carbonated_concrete_check.Location = new System.Drawing.Point(222, 378);
            this.carbonated_concrete_check.Name = "carbonated_concrete_check";
            this.carbonated_concrete_check.Size = new System.Drawing.Size(99, 17);
            this.carbonated_concrete_check.TabIndex = 3;
            this.carbonated_concrete_check.Text = "Карбонатный";
            this.carbonated_concrete_check.UseVisualStyleBackColor = true;
            // 
            // silicate_concrete_check
            // 
            this.silicate_concrete_check.AutoSize = true;
            this.silicate_concrete_check.Checked = true;
            this.silicate_concrete_check.Location = new System.Drawing.Point(222, 356);
            this.silicate_concrete_check.Name = "silicate_concrete_check";
            this.silicate_concrete_check.Size = new System.Drawing.Size(91, 17);
            this.silicate_concrete_check.TabIndex = 2;
            this.silicate_concrete_check.TabStop = true;
            this.silicate_concrete_check.Text = "Силикатный";
            this.silicate_concrete_check.UseVisualStyleBackColor = true;
            // 
            // fire_resist_checkbox
            // 
            this.fire_resist_checkbox.AutoSize = true;
            this.fire_resist_checkbox.Location = new System.Drawing.Point(13, 356);
            this.fire_resist_checkbox.Name = "fire_resist_checkbox";
            this.fire_resist_checkbox.Size = new System.Drawing.Size(160, 17);
            this.fire_resist_checkbox.TabIndex = 1;
            this.fire_resist_checkbox.Text = "Проверка огнестойкости";
            this.fire_resist_checkbox.UseVisualStyleBackColor = true;
            // 
            // fire_safety_checkbox
            // 
            this.fire_safety_checkbox.AutoSize = true;
            this.fire_safety_checkbox.Location = new System.Drawing.Point(13, 379);
            this.fire_safety_checkbox.Name = "fire_safety_checkbox";
            this.fire_safety_checkbox.Size = new System.Drawing.Size(175, 17);
            this.fire_safety_checkbox.TabIndex = 0;
            this.fire_safety_checkbox.Text = "Проверка огнесохранности";
            this.fire_safety_checkbox.UseVisualStyleBackColor = true;
            // 
            // TopMenuStrip
            // 
            this.TopMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.инструкцияToolStripMenuItem,
            this.помощьToolStripMenuItem});
            this.TopMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.TopMenuStrip.Name = "TopMenuStrip";
            this.TopMenuStrip.Size = new System.Drawing.Size(634, 24);
            this.TopMenuStrip.TabIndex = 27;
            this.TopMenuStrip.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.сохранитьToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // сохранитьToolStripMenuItem
            // 
            this.сохранитьToolStripMenuItem.Name = "сохранитьToolStripMenuItem";
            this.сохранитьToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.сохранитьToolStripMenuItem.Text = "Сохранить ";
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            // 
            // инструкцияToolStripMenuItem
            // 
            this.инструкцияToolStripMenuItem.Name = "инструкцияToolStripMenuItem";
            this.инструкцияToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.инструкцияToolStripMenuItem.Text = "Инструкция";
            // 
            // помощьToolStripMenuItem
            // 
            this.помощьToolStripMenuItem.Name = "помощьToolStripMenuItem";
            this.помощьToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.помощьToolStripMenuItem.Text = "Помощь";
            // 
            // acceptinputbutton
            // 
            this.acceptinputbutton.Location = new System.Drawing.Point(16, 311);
            this.acceptinputbutton.Name = "acceptinputbutton";
            this.acceptinputbutton.Size = new System.Drawing.Size(204, 23);
            this.acceptinputbutton.TabIndex = 23;
            this.acceptinputbutton.Text = "Подтвердить ввод";
            this.acceptinputbutton.UseVisualStyleBackColor = true;
            this.acceptinputbutton.Click += new System.EventHandler(this.acceptinputbutton_Click);
            // 
            // Calculatebutton
            // 
            this.Calculatebutton.Location = new System.Drawing.Point(395, 102);
            this.Calculatebutton.Name = "Calculatebutton";
            this.Calculatebutton.Size = new System.Drawing.Size(204, 23);
            this.Calculatebutton.TabIndex = 24;
            this.Calculatebutton.Text = "Начать расчёт";
            this.Calculatebutton.UseVisualStyleBackColor = true;
            this.Calculatebutton.Click += new System.EventHandler(this.Calculatebutton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(634, 450);
            this.Controls.Add(this.TopMenuStrip);
            this.Controls.Add(this.RSU_panel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Form1";
            this.RSU_panel.ResumeLayout(false);
            this.RSU_panel.PerformLayout();
            this.panelparameters.ResumeLayout(false);
            this.panelparameters.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.step_tNUD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.T_0NUD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t_TNUD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WeightNUD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HeightNUD)).EndInit();
            this.tavr_panel.ResumeLayout(false);
            this.tavr_panel.PerformLayout();
            this.quadrant_panel.ResumeLayout(false);
            this.quadrant_panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.WvalueNUD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.betonRoNUD)).EndInit();
            this.TopMenuStrip.ResumeLayout(false);
            this.TopMenuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel RSU_panel;
        private System.Windows.Forms.CheckBox fire_resist_checkbox;
        private System.Windows.Forms.CheckBox fire_safety_checkbox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton carbonated_concrete_check;
        private System.Windows.Forms.RadioButton silicate_concrete_check;
        private System.Windows.Forms.NumericUpDown betonRoNUD;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox Armaturecombobox;
        private System.Windows.Forms.NumericUpDown WvalueNUD;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MenuStrip TopMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem инструкцияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem помощьToolStripMenuItem;
        private System.Windows.Forms.ComboBox A500choice;
        private System.Windows.Forms.Label label_arm;
        private System.Windows.Forms.ComboBox A700choice;
        private System.Windows.Forms.ComboBox A600choice;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel tavr_panel;
        private System.Windows.Forms.Panel quadrant_panel;
        private System.Windows.Forms.CheckBox Quadrantdownsidecheck;
        private System.Windows.Forms.CheckBox Quadrantupsidecheck;
        private System.Windows.Forms.CheckBox Quadrantrightsidecheck;
        private System.Windows.Forms.CheckBox Quadrantleftsidecheck;
        private System.Windows.Forms.Panel panelparameters;
        private System.Windows.Forms.Button parametersbut;
        private System.Windows.Forms.CheckBox tavrupsidescheck;
        private System.Windows.Forms.CheckBox tavrallsidescheck;
        private System.Windows.Forms.CheckBox tavrdownsidescheck;
        private System.Windows.Forms.NumericUpDown T_0NUD;
        private System.Windows.Forms.NumericUpDown t_TNUD;
        private System.Windows.Forms.NumericUpDown WeightNUD;
        private System.Windows.Forms.NumericUpDown HeightNUD;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox FuncTCombobox;
        private System.Windows.Forms.NumericUpDown step_tNUD;
        private System.Windows.Forms.ToolStripMenuItem сохранитьToolStripMenuItem;
        private System.Windows.Forms.Button acceptinputbutton;
        private System.Windows.Forms.Button Calculatebutton;
    }
}

