﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace eur12
{
   
    public partial class Form1 : Form
    {
        //промежуточные переменные для хранения состояния
        private bool flag_struct = true;
        private bool fire_resistance = false;
        private bool fire_safety = false;
     
        // Входные данные
        private double W; // Влажность бетона, %
        private double ro; // Плотность бетона, кг/куб. м
        private double height = 0; // Высота сечения, м
        private double width = 0 ; // Ширина сечения, м
        private double T_0 = 20; // Начальная температура, С
        private double t_T; // Время нагрева, с
        private double tmax = 0; // длительность пожара, мин
        private double stepT = 0;

        // Выходные данные
        private double[,] T; // Температура в точках сечения
        private double[] X; // Координаты X точек сечения
        private double[] Y; // Координаты Y точек сечения



        // Промежуточные данные
        private double l1; // Константа для расчёта к-та теплопроводности (силикатный заполнитель или керамзитобетон)
        private double l2; // Константа для расчёта к-та теплопроводности (карбонатный заполнитель)
        private double c1; // Константа для расчёта к-та теплоёмкости (силикатный заполнитель или керамзитобетон)
        private double c2; // Константа для расчёта к-та теплоёмкости (карбонатный заполнитель)
        private double[,] T1; // Температура на 1-м этапе расчёта
        private double[,] T2; // Температура на 2-м этапе расчёта


        private double T_1; // Текущая температура нагрева, С
        private double time = 0.0; // Текущяя длительность нагрева, с


        private double t_step; // Шаг по времени, с
        private double hx_step; // Шаг по координате X (горизонтальная ось), м
        private double hy_step; // Шаг по координате Y (вертикальная ось), м


        private double[,] lambda; // К-т теплопроводности
        private double[,] c; // К-т теплоёмкости
        private double[,] a; // К-т температуропроводности


        private double[,] alpha_x; // Прогоночные к-ты (направление вдоль оси X)
        private double[,] beta_x; // Прогоночные к-ты (направление вдоль оси X)
        private double[,] alpha_y; // Прогоночные к-ты (направление вдоль оси Y)
        private double[,] beta_y; // Прогоночные к-ты (направление вдоль оси Y)


        private double[] Qr_LeftSide; // Лучистый тепловой поток (левая граница сечения)
        private double[] Qr_RightSide; // Лучистый тепловой поток (правая граница сечения)
        private double[] Qr_UpSide; // Лучистый тепловой поток (верхняя граница сечения)
        private double[] Qr_DownSide; // Лучистый тепловой поток (нижняя граница сечения) 

        private double[] alpha_LeftSide; // К-т теплоотдачи (левая граница сечения)
        private double[] alpha_RightSide; // К-т теплоотдачи (правая граница сечения)
        private double[] alpha_UpSide; // К-т теплоотдачи (верхняя граница сечения)
        private double[] alpha_DownSide; // К-т теплоотдачи (нижняя граница сечения)


        // К-ты для рачёта прогоночных к-в на 1-м этапе
        private double[,] Ax;
        private double[,] Bx;
        private double[,] Cx;
        private double[,] Fx;

        
        // К-ты для рачёта прогоночных к-в на 2-м этапе
        private double[,] Ay;
        private double[,] By;
        private double[,] Cy;
        private double[,] Fy;

        private double rx; // Число Куранта (для оси X)
        private double ry; // Число Куранта (для оси Y)


        private double epsilon_heat = 0.56; // К-т пропорциональности для нагреваемой стороны
        private double epsilon_cooling = 0.63; // К-т пропорциональности для охлаждаемой стороны



        private int N = 500; // Число временных шагов
        private int Kx = 40; // Число шагов по координате X
        private int Ky = 40; // Число шагов по координате Y

        // Входные данные
        //private double W; // Влажность бетона, %
        // private double ro; // Плотность бетона, кг/куб. м
        //private double height = 0; // Высота сечения, м
        //private double width = 0; // Ширина сечения, м
        // private double T_0 = 20; // Начальная температура, С
        // private double t_T; // Время нагрева, с
        //private double tmax = 0; // длительность пожара, мин
        // private double stepT = 0;


        private void PCalculate()    
        {
            //промежуточные расчёты
            hx_step = width / Kx;
            hy_step = height / Ky;
            t_step = t_T / N;
            rx = t_step / hx_step / hx_step;
            ry = t_step / hy_step / hy_step;
            Qr_LeftSide = new double[Ky + 1];
            Qr_RightSide = new double[Ky + 1];
            Qr_UpSide = new double[Kx + 1];
            Qr_DownSide = new double[Kx + 1];
            alpha_LeftSide = new double[Ky + 1];
            alpha_RightSide = new double[Ky + 1];
            alpha_UpSide = new double[Kx + 1];
            alpha_DownSide = new double[Kx + 1];
            T = new double[Ky + 1, Kx + 1];
            T1 = new double[Ky + 1, Kx + 1];
            T2 = new double[Ky + 1, Kx + 1];
            alpha_x = new double[Ky + 1, Kx + 1];
            beta_x = new double[Ky + 1, Kx + 1];
            alpha_y = new double[Ky + 1, Kx + 1];
            beta_y = new double[Ky + 1, Kx + 1];
            lambda = new double[Ky + 1, Kx + 1];
            c = new double[Ky + 1, Kx + 1];
            a = new double[Ky + 1, Kx + 1];
            Ax = new double[Ky + 1, Kx + 1];
            Bx = new double[Ky + 1, Kx + 1];
            Cx = new double[Ky + 1, Kx + 1];
            Fx = new double[Ky + 1, Kx + 1];
            Ay = new double[Ky + 1, Kx + 1];
            By = new double[Ky + 1, Kx + 1];
            Cy = new double[Ky + 1, Kx + 1];
            Fy = new double[Ky + 1, Kx + 1];
            X = new double[Kx + 1];
            Y = new double[Ky + 1];
            //в зависимости от типа бетона присваиваем переменным для расчёта значение
            if (silicate_concrete_check.Checked)
            {
                l1 = 1.2;
                l2 = 0.00035;
                c1 = 0.71;
                c2 = 0.00083;
            }

            else if (carbonated_concrete_check.Checked)
            {
                l1 = 1.14;
                l2 = 0.00055;
                c1 = 0.71;
                c2 = 0.00083;
            }

            else
            {
                l1 = 0.36;
                l2 = 0.00012;
                c1 = 0.83;
                c2 = 0.00042;
            }

            // Начальное условие: T[i] = T0 при t = 0;
            for (int j = Ky / 2; j <= Ky; j++)
            {
                for (int i = 0; i <= Kx; i++)
                {
                    T1[j, i] = T_0;
                }
            }


            for (int j = Ky / 2; j <= Ky; j++)
            {
                for (int i = 0; i <= Kx; i++)
                {
                    T2[j, i] = T_0;
                }
            }

            // Координаты X точек сечения
            for (int i = 0; i <= Kx; i++)
            {
                X[i] = i * hx_step;
            }


            // Координаты Y точек сечения
            for (int j = 0; j <= Ky; j++)
            {
                Y[j] = j * hy_step;
            }
            // Нагрев 1 стороны

            if (Quadrantleftsidecheck.Checked && !Quadrantupsidecheck.Checked && !Quadrantrightsidecheck.Checked && !Quadrantdownsidecheck.Checked
                || Quadrantupsidecheck.Checked && !Quadrantleftsidecheck.Checked && !Quadrantrightsidecheck.Checked && !Quadrantdownsidecheck.Checked
                || Quadrantrightsidecheck.Checked && !Quadrantupsidecheck.Checked && !Quadrantleftsidecheck.Checked && !Quadrantdownsidecheck.Checked
                || Quadrantdownsidecheck.Checked && !Quadrantupsidecheck.Checked && !Quadrantrightsidecheck.Checked && !Quadrantleftsidecheck.Checked)


            {
                // Основной цикл
                while (time <= t_T)
                {


                    T_1 = 345 * Math.Log10(8 * time / 60 + 1) + T_0; // time = [мин]


                    // К-ты теплоотдачи на границах сечения
                    for (int j = Ky / 2; j <= Ky; j++)
                    {
                        alpha_LeftSide[j] = 29.0;
                    }

                    for (int j = Ky / 2; j <= Ky; j++)
                    {
                        alpha_RightSide[j] = 1.5 * Math.Pow(Math.Round(T1[j, Kx] - 20), 1.0 / 3.0);
                    }

                    for (int i = 0; i <= Kx; i++)
                    {
                        alpha_DownSide[i] = 1.5 * Math.Pow(Math.Round(T1[Ky, i] - 20), 1.0 / 3.0);
                    }




                    // Лучистый тепловой поток на границах сечения
                    for (int j = Ky / 2; j <= Ky; j++)
                    {
                        Qr_LeftSide[j] = 5.67 * epsilon_heat * (Math.Pow(0.01 * T_1 + 2.73, 4) - Math.Pow(0.01 * T1[j, 0] + 2.73, 4));
                    }

                    for (int j = Ky / 2; j <= Ky; j++)
                    {
                        Qr_RightSide[j] = 5.67 * epsilon_cooling * (Math.Pow(0.01 * T_0 + 2.73, 4) - Math.Pow(0.01 * T1[j, Kx] + 2.73, 4));
                    }

                    for (int i = 0; i <= Kx; i++)
                    {
                        Qr_DownSide[i] = 5.67 * epsilon_cooling * (Math.Pow(0.01 * T_0 + 2.73, 4) - Math.Pow(0.01 * T1[Ky, i] + 2.73, 4));
                    }



                    // Коэффициенты теплоёмкости и теплопроводности в каждом точке
                    for (int j = Ky / 2; j <= Ky; j++)
                    {
                        for (int i = 0; i <= Kx; i++)
                        {
                            lambda[j, i] = l1 - l2 * T2[j, i];
                            c[j, i] = (c1 + c2 * T2[j, i]) * 1000;
                        }
                    }



                    // Коэффициент температуропроводности в каждой точке
                    for (int j = Ky / 2; j <= Ky; j++)
                    {
                        for (int i = 0; i <= Kx; i++)
                        {
                            a[j, i] = lambda[j, i] / (c[j, i] + 50 * W) / ro;
                        }
                    }


                    // Прогоночные к-ты для нулевых точек
                    for (int j = Ky / 2 + 1; j <= Ky - 1; j++)
                    {
                        alpha_x[j, 0] = (a[j, 0] + a[j, 1]) * t_step * 0.5 * (lambda[j, 0] + lambda[j, 1])
                            / (0.5 * (lambda[j, 0] + lambda[j, 1]) * hx_step * hx_step + (a[j, 0] + a[j, 1]) * t_step * (0.5 * (lambda[j, 0] + lambda[j, 1]) + alpha_LeftSide[j] * hx_step));
                        beta_x[j, 0] = (0.5 * (lambda[j, 0] + lambda[j, 1]) * hx_step * hx_step * T1[j, 0] + (a[j, 0] + a[j, 1]) * t_step * alpha_LeftSide[j] * hx_step * T_1 + hx_step * t_step * (a[j, 0] + a[j, 1]) * Qr_LeftSide[j])
                            / (0.5 * (lambda[j, 0] + lambda[j, 1]) * hx_step * hx_step + (a[j, 0] + a[j, 1]) * t_step * (0.5 * (lambda[j, 0] + lambda[j, 1]) + alpha_LeftSide[j] * hx_step));
                    }




                    // Аx, Вx, Сx, Fx
                    for (int j = Ky / 2 + 1; j <= Ky - 1; j++)
                    {
                        for (int i = 1; i <= Kx - 1; i++)
                        {
                            Ax[j, i] = -0.5 * (a[j, i] + a[j, i - 1]) * rx;
                            Bx[j, i] = 0.5 * rx * (a[j, i + 1] + 2 * a[j, i] + a[j, i - 1]) + 1;
                            Cx[j, i] = -0.5 * (a[j, i + 1] + a[j, i]) * rx;
                            Fx[j, i] = T2[j, i];
                        }
                    }



                    // Прогоночные коэффициенты 
                    for (int j = Ky / 2 + 1; j <= Ky - 1; j++)
                    {
                        for (int i = 1; i <= Kx - 1; i++)
                        {
                            alpha_x[j, i] = -Cx[j, i] / (Ax[j, i] * alpha_x[j, i - 1] + Bx[j, i]);
                            beta_x[j, i] = (Fx[j, i] - Ax[j, i] * beta_x[j, i - 1]) / (Ax[j, i] * alpha_x[j, i - 1] + Bx[j, i]);
                        }
                    }





                    // Температура в Kx-тых точках
                    for (int j = Ky / 2 + 1; j <= Ky - 1; j++)
                    {
                        T1[j, Kx] = ((a[j, Kx] + a[j, Kx - 1]) * t_step * (hx_step * (alpha_RightSide[j] * T_0 + Qr_RightSide[j]) + 0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) * beta_x[j, Kx - 1]) + 0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) * hx_step * hx_step * T1[j, Kx])
                            / (0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) * hx_step * hx_step + (a[j, Kx] + a[j, Kx - 1]) * t_step * (0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) * (1 - alpha_x[j, Kx / 2 - 1]) + alpha_RightSide[j] * hx_step));
                    }




                    // Температуры во внутренних точках 
                    for (int j = Ky / 2 + 1; j <= Ky - 1; j++)
                    {
                        for (int i = Kx - 1; i >= 0; i--)
                        {
                            T1[j, i] = alpha_x[j, i] * T1[j, i + 1] + beta_x[j, i];
                        }
                    }




                    // Граничное условие (верхняя сторона) 
                    for (int i = 0; i <= Kx; i++)
                    {
                        T1[Ky / 2, i] = T1[Ky / 2 + 1, i];
                    }




                    // Граничное условие (нижняя сторона)
                    for (int i = 1; i <= Kx; i++)
                    {
                        T1[Ky, i] = ((a[Ky, i] + a[Ky - 1, i]) * t_step * (hy_step * (alpha_DownSide[i] * T_0 + Qr_DownSide[i]) + 0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * T1[Ky - 1, i]) + 0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * hy_step * hy_step * T1[Ky, i])
                            / ((a[Ky, i] + a[Ky - 1, i]) * t_step * (0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) + alpha_DownSide[i] * hy_step) + 0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * hy_step * hy_step);
                    }


                    // Угловая точка
                    T1[Ky, 0] = T1[Ky - 1, 0];





                    // 2 этап



                    // К-ты теплоотдачи на границах сечения
                    for (int j = Ky / 2; j <= Ky; j++)
                    {
                        alpha_RightSide[j] = 1.5 * Math.Pow(Math.Round(T2[j, Kx] - 20), 1.0 / 3.0);
                    }

                    for (int i = 0; i <= Kx; i++)
                    {
                        alpha_DownSide[i] = 1.5 * Math.Pow(Math.Round(T2[Ky, i] - 20), 1.0 / 3.0);
                    }




                    // Лучистый тепловой поток на границах сечения
                    for (int j = Ky / 2; j <= Ky; j++)
                    {
                        Qr_LeftSide[j] = 5.67 * epsilon_heat * (Math.Pow(0.01 * T_1 + 2.73, 4) - Math.Pow(0.01 * T2[j, 0] + 2.73, 4));
                    }

                    for (int j = Ky / 2; j <= Ky; j++)
                    {
                        Qr_RightSide[j] = 5.67 * epsilon_cooling * (Math.Pow(0.01 * T_0 + 2.73, 4) - Math.Pow(0.01 * T2[j, Kx] + 2.73, 4));
                    }

                    for (int i = 0; i <= Kx; i++)
                    {
                        Qr_DownSide[i] = 5.67 * epsilon_cooling * (Math.Pow(0.01 * T_0 + 2.73, 4) - Math.Pow(0.01 * T2[Ky, i] + 2.73, 4));
                    }




                    // Прогоночные к-ты для нулевой точки = const
                    for (int i = 1; i <= Kx - 1; i++)
                    {
                        alpha_y[Ky / 2, i] = (a[Ky / 2, i] + a[Ky / 2 + 1, i]) * t_step
                            / (hy_step * hy_step + (a[Ky / 2, i] + a[Ky / 2 + 1, i]) * t_step);
                        beta_y[Ky / 2, i] = hy_step * hy_step * T1[Ky / 2, i]
                            / (hy_step * hy_step + (a[Ky / 2, i] + a[Ky / 2 + 1, i]) * t_step);
                    }




                    // Аy, Вy, Сy, Fy
                    for (int i = 1; i <= Kx - 1; i++)
                    {
                        for (int j = Ky / 2 + 1; j <= Ky - 1; j++)
                        {
                            Ay[j, i] = -0.5 * (a[j, i] + a[j - 1, i]) * ry;
                            By[j, i] = 0.5 * ry * (a[j + 1, i] + 2 * a[j, i] + a[j - 1, i]) + 1;
                            Cy[j, i] = -0.5 * (a[j + 1, i] + a[j, i]) * ry;
                            Fy[j, i] = T1[j, i];
                        }
                    }



                    // Прогоночные коэффициенты 
                    for (int i = 1; i <= Kx - 1; i++)
                    {
                        for (int j = Ky / 2 + 1; j <= Ky - 1; j++)
                        {
                            alpha_y[j, i] = -Cy[j, i] / (Ay[j, i] * alpha_y[j - 1, i] + By[j, i]);
                            beta_y[j, i] = (Fy[j, i] - Ay[j, i] * beta_y[j - 1, i]) / (Ay[j, i] * alpha_y[j - 1, i] + By[j, i]);
                        }
                    }




                    // Температуры в Ky-ых точках
                    for (int i = 1; i <= Kx - 1; i++)
                    {
                        T2[Ky, i] = ((a[Ky, i] + a[Ky - 1, i]) * t_step * (hy_step * (alpha_DownSide[i] * T_0 + Qr_DownSide[i]) + 0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * beta_y[Ky - 1, i]) + 0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * hy_step * hy_step * T2[Ky, i])
                            / (0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * hy_step * hy_step + (a[Ky, i] + a[Ky - 1, i]) * t_step * (0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * (1 - alpha_y[Ky - 1, i]) + alpha_DownSide[i] * hy_step));
                    }




                    // Температуры во внутренних точках
                    for (int i = 1; i <= Kx - 1; i++)
                    {
                        for (int j = Ky - 1; j >= Ky / 2; j--)
                        {
                            T2[j, i] = alpha_y[j, i] * T2[j + 1, i] + beta_y[j, i];
                        }
                    }




                    // Граничное условие при (левая сторона) 
                    for (int j = Ky / 2; j <= Ky - 1; j++)
                    {
                        T2[j, 0] = ((a[j, 0] + a[j, 1]) * t_step * 0.5 * (lambda[j, 1] + lambda[j, 0]) * T2[j, 1] + hx_step * hx_step * 0.5 * (lambda[j, 0] + lambda[j, 1]) * T2[j, 0] + (a[j, 0] + a[j, 1]) * t_step * alpha_LeftSide[j] * hx_step * T_1 + hx_step * t_step * (a[j, 0] + a[j, 1]) * Qr_LeftSide[j])
                            / (hx_step * hx_step * 0.5 * (lambda[j, 0] + lambda[j, 1]) + (a[j, 0] + a[j, 1]) * t_step * (0.5 * (lambda[j, 0] + lambda[j, 1]) + alpha_LeftSide[j] * hx_step));
                    }

                    T2[Ky, 0] = T2[Ky - 1, 0];





                    // Граничное условие при (правая сторона)
                    for (int j = Ky / 2; j <= Ky; j++)
                    {
                        T2[j, Kx] = ((a[j, Kx] + a[j, Kx - 1]) * t_step * 0.5 * (lambda[j, Kx - 1] + lambda[j, Kx]) * T[j, Kx - 1] + hx_step * hx_step * 0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) * T2[j, Kx] + (a[j, Kx] + a[j, Kx - 1]) * t_step * alpha_RightSide[j] * hx_step * T_0 + hx_step * t_step * (a[j, Kx] + a[j, Kx - 1]) * Qr_RightSide[j])
                            / (hx_step * hx_step * 0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) + (a[j, Kx] + a[j, Kx - 1]) * t_step * (0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) + alpha_RightSide[j] * hx_step));
                    }

                    time += t_step;
                }





                // Левая сторона нагрета
                if (Quadrantleftsidecheck.Checked && !Quadrantupsidecheck.Checked && !Quadrantrightsidecheck.Checked && !Quadrantdownsidecheck.Checked)
                {

                    // 3 и 4 четверти
                    for (int j = Ky / 2; j <= Ky; j++)
                    {
                        for (int i = 0; i <= Kx; i++)
                        {
                            T[j, i] = Math.Round(T2[j, i]);
                        }
                    }

                    // 1 и 2 четверти
                    for (int j = 0; j <= Ky / 2; j++)
                    {
                        for (int i = 0; i <= Kx; i++)
                        {
                            T[j, i] = T[Ky - j, i];
                        }
                    }
                }





                // Правая сторона
                if (Quadrantrightsidecheck.Checked && !Quadrantupsidecheck.Checked && !Quadrantleftsidecheck.Checked && !Quadrantdownsidecheck.Checked)
                {

                    // 3 и 4 четверти
                    for (int j = Ky / 2; j <= Ky; j++)
                    {
                        for (int i = 0; i <= Kx; i++)
                        {
                            T[j, i] = Math.Round(T2[j, Kx - i]);
                        }
                    }

                    // 1 и 2 четверти
                    for (int j = 0; j <= Ky / 2; j++)
                    {
                        for (int i = 0; i <= Kx; i++)
                        {
                            T[j, i] = T[Ky - j, i];
                        }
                    }
                }




                // Верхняя сторона
                if (Quadrantupsidecheck.Checked && !Quadrantleftsidecheck.Checked && !Quadrantrightsidecheck.Checked && !Quadrantdownsidecheck.Checked)
                {

                    // 2 и 3 четверти
                    for (int j = 0; j <= Ky; j++)
                    {
                        for (int i = 0; i <= Kx / 2; i++)
                        {
                            T[j, i] = Math.Round(T2[Ky - i, j]);
                        }
                    }

                    // 1 и 4 четверти
                    for (int j = 0; j <= Ky; j++)
                    {
                        for (int i = Kx; i >= Kx / 2; i--)
                        {
                            T[j, i] = T[j, Kx - i];
                        }
                    }
                }





                // Нижняя сторона
                if (Quadrantdownsidecheck.Checked && !Quadrantupsidecheck.Checked && !Quadrantrightsidecheck.Checked && !Quadrantleftsidecheck.Checked)
                {

                    // 1 и 4 четверти
                    for (int j = Ky; j >= 0; j--)
                    {
                        for (int i = Kx / 2; i <= Kx; i++)
                        {
                            T[j, i] = Math.Round(T2[i, Kx - j]);
                        }
                    }

                    // 2 и 3 четверти
                    for (int j = 0; j <= Ky; j++)
                    {
                        for (int i = 0; i <= Kx / 2; i++)
                        {
                            T[j, i] = T[j, Kx - i];
                        }
                    }
                }
            }

            // Нагрев 2 смежных сторон
            if (Quadrantleftsidecheck.Checked && Quadrantupsidecheck.Checked && !Quadrantrightsidecheck.Checked && !Quadrantdownsidecheck.Checked
                || Quadrantupsidecheck.Checked && Quadrantrightsidecheck.Checked && !Quadrantleftsidecheck.Checked && !Quadrantdownsidecheck.Checked
                || Quadrantrightsidecheck.Checked && Quadrantdownsidecheck.Checked && !Quadrantupsidecheck.Checked && !Quadrantleftsidecheck.Checked
                || Quadrantdownsidecheck.Checked && Quadrantleftsidecheck.Checked && !Quadrantupsidecheck.Checked && !Quadrantrightsidecheck.Checked)

            {
                // Основной цикл
                while (time <= t_T)
                {


                    T_1 = 345 * Math.Log10(8 * time / 60 + 1) + T_0; // time = [мин]



                    // К-ты теплоотдачи на границах сечения
                    for (int j = 0; j <= Ky; j++)
                    {
                        alpha_LeftSide[j] = 29.0;
                    }

                    for (int j = 0; j <= Ky; j++)
                    {
                        alpha_RightSide[j] = 1.5 * Math.Pow(Math.Round(T1[j, Kx] - 20), 1.0 / 3.0);
                    }

                    for (int i = 0; i <= Kx; i++)
                    {
                        alpha_UpSide[i] = 29.0;
                    }

                    for (int i = 0; i <= Kx; i++)
                    {
                        alpha_DownSide[i] = 1.5 * Math.Pow(Math.Round(T1[Ky, i] - 20), 1.0 / 3.0);
                    }



                    // Лучистый тепловой поток на границах сечения
                    for (int j = 0; j <= Ky; j++)
                    {
                        Qr_LeftSide[j] = 5.67 * epsilon_heat * (Math.Pow(0.01 * T_1 + 2.73, 4) - Math.Pow(0.01 * T1[j, 0] + 2.73, 4));
                    }

                    for (int j = 0; j <= Ky; j++)
                    {
                        Qr_RightSide[j] = 5.67 * epsilon_cooling * (Math.Pow(0.01 * T_0 + 2.73, 4) - Math.Pow(0.01 * T1[j, Kx] + 2.73, 4));
                    }

                    for (int i = 0; i <= Kx; i++)
                    {
                        Qr_UpSide[i] = 5.67 * epsilon_heat * (Math.Pow(0.01 * T_1 + 2.73, 4) - Math.Pow(0.01 * T1[0, i] + 2.73, 4));
                    }

                    for (int i = 0; i <= Kx; i++)
                    {
                        Qr_DownSide[i] = 5.67 * epsilon_cooling * (Math.Pow(0.01 * T_0 + 2.73, 4) - Math.Pow(0.01 * T1[Ky, i] + 2.73, 4));
                    }




                    // Коэффициенты теплоёмкости и теплопроводности в каждом точке
                    for (int j = 0; j <= Ky; j++)
                    {
                        for (int i = 0; i <= Kx; i++)
                        {
                            lambda[j, i] = l1 - l2 * T2[j, i];
                            c[j, i] = (c1 + c2 * T2[j, i]) * 1000;
                        }
                    }



                    // Коэффициент температуропроводности в каждой точке
                    for (int j = 0; j <= Ky; j++)
                    {
                        for (int i = 0; i <= Kx; i++)
                        {
                            a[j, i] = lambda[j, i] / (c[j, i] + 50 * W) / ro;
                        }
                    }



                    // Прогоночные к-ты для нулевой точки = const
                    for (int j = 1; j <= Ky - 1; j++)
                    {
                        alpha_x[j, 0] = (a[j, 0] + a[j, 1]) * t_step * 0.5 * (lambda[j, 0] + lambda[j, 1])
                            / (0.5 * (lambda[j, 0] + lambda[j, 1]) * hx_step * hx_step + (a[j, 0] + a[j, 1]) * t_step * (0.5 * (lambda[j, 0] + lambda[j, 1]) + alpha_LeftSide[j] * hx_step));
                        beta_x[j, 0] = (0.5 * (lambda[j, 0] + lambda[j, 1]) * hx_step * hx_step * T1[j, 0] + (a[j, 0] + a[j, 1]) * t_step * alpha_LeftSide[j] * hx_step * T_1 + hx_step * t_step * (a[j, 0] + a[j, 1]) * Qr_LeftSide[j])
                            / (0.5 * (lambda[j, 0] + lambda[j, 1]) * hx_step * hx_step + (a[j, 0] + a[j, 1]) * t_step * (0.5 * (lambda[j, 0] + lambda[j, 1]) + alpha_LeftSide[j] * hx_step));
                    }




                    // Аx, Вx, Сx, Fx
                    for (int j = 1; j <= Ky - 1; j++)
                    {
                        for (int i = 1; i <= Kx - 1; i++)
                        {
                            Ax[j, i] = -0.5 * (a[j, i] + a[j, i - 1]) * rx;
                            Bx[j, i] = 0.5 * rx * (a[j, i + 1] + 2 * a[j, i] + a[j, i - 1]) + 1;
                            Cx[j, i] = -0.5 * (a[j, i + 1] + a[j, i]) * rx;
                            Fx[j, i] = T2[j, i];
                        }
                    }

                    // Прогоночные коэффициенты 
                    for (int j = 1; j <= Ky - 1; j++)
                    {
                        for (int i = 1; i <= Kx - 1; i++)
                        {
                            alpha_x[j, i] = -Cx[j, i] / (Ax[j, i] * alpha_x[j, i - 1] + Bx[j, i]);
                            beta_x[j, i] = (Fx[j, i] - Ax[j, i] * beta_x[j, i - 1]) / (Ax[j, i] * alpha_x[j, i - 1] + Bx[j, i]);
                        }
                    }



                    // Температуры в Кx-ых точках
                    for (int j = 1; j <= Ky - 1; j++)
                    {
                        T1[j, Kx] = ((a[j, Kx] + a[j, Kx - 1]) * t_step * (hx_step * (alpha_RightSide[j] * T_0 + Qr_RightSide[j]) + 0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) * beta_x[j, Kx - 1]) + 0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) * hx_step * hx_step * T1[j, Kx])
                            / (0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) * hx_step * hx_step + (a[j, Kx] + a[j, Kx - 1]) * t_step * (0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) * (1 - alpha_x[j, Kx - 1]) + alpha_RightSide[j] * hx_step));
                    }




                    // Температуры во внутренних точках
                    for (int j = 1; j <= Ky - 1; j++)
                    {
                        for (int i = Kx - 1; i >= 0; i--)
                        {
                            T1[j, i] = alpha_x[j, i] * T1[j, i + 1] + beta_x[j, i];
                        }
                    }




                    // Граничное условие (левая граница)
                    for (int i = 0; i <= Kx - 1; i++)
                    {
                        T1[0, i] = ((a[0, i] + a[1, i]) * t_step * 0.5 * (lambda[0, i] + lambda[1, i]) * T1[1, i] + hy_step * hy_step * 0.5 * (lambda[0, i] + lambda[1, i]) * T1[0, i] + alpha_UpSide[i] * hy_step * t_step * T_1 * (a[0, i] + a[1, i]) + hy_step * t_step * (a[0, i] + a[1, i]) * Qr_UpSide[i])
                            / (hy_step * hy_step * 0.5 * (lambda[0, i] + lambda[1, i]) + (a[0, i] + a[1, i]) * t_step * (0.5 * (lambda[0, i] + lambda[1, i]) + alpha_UpSide[i] * hy_step));
                    }

                    T1[0, Kx] = T1[0, Kx - 1];


                    // Граничное условие при (правая граница)
                    for (int i = 1; i <= Kx; i++)
                    {
                        T1[Ky, i] = ((a[Ky, i] + a[Ky - 1, i]) * t_step * (hy_step * (alpha_DownSide[i] * T_0 + Qr_DownSide[i]) + 0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * T1[Ky - 1, i]) + 0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * hy_step * hy_step * T2[Ky, i])
                            / ((a[Ky, i] + a[Ky - 1, i]) * t_step * (0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) + alpha_DownSide[i] * hy_step) + 0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * hy_step * hy_step);
                    }


                    // Угловая точка
                    T1[Ky, 0] = T1[Ky - 1, 0];




                    // 2 этап



                    // К-ты теплоотдачи на границах сечения
                    for (int j = 0; j <= Ky; j++)
                    {
                        alpha_RightSide[j] = 1.5 * Math.Pow(Math.Round(T2[j, Kx] - 20), 1.0 / 3.0);
                    }

                    for (int i = 0; i <= Kx; i++)
                    {
                        alpha_DownSide[i] = 1.5 * Math.Pow(Math.Round(T2[Ky, i] - 20), 1.0 / 3.0);
                    }



                    // Лучистый тепловой поток на границах сечения
                    for (int j = 0; j <= Ky / 2; j++)
                    {
                        Qr_LeftSide[j] = 5.67 * epsilon_heat * (Math.Pow(0.01 * T_1 + 2.73, 4) - Math.Pow(0.01 * T2[j, 0] + 2.73, 4));
                    }

                    for (int j = 0; j <= Ky; j++)
                    {
                        Qr_RightSide[j] = 5.67 * epsilon_cooling * (Math.Pow(0.01 * T_0 + 2.73, 4) - Math.Pow(0.01 * T2[j, Kx] + 2.73, 4));
                    }

                    for (int i = 0; i <= Kx; i++)
                    {
                        Qr_UpSide[i] = 5.67 * epsilon_heat * (Math.Pow(0.01 * T_1 + 2.73, 4) - Math.Pow(0.01 * T2[0, i] + 2.73, 4));
                    }

                    for (int i = 0; i <= Kx; i++)
                    {
                        Qr_DownSide[i] = 5.67 * epsilon_cooling * (Math.Pow(0.01 * T_0 + 2.73, 4) - Math.Pow(0.01 * T2[Ky, i] + 2.73, 4));
                    }



                    // Прогоночные к-ты для нулевой точки = const
                    for (int i = 1; i <= Kx - 1; i++)
                    {
                        alpha_y[0, i] = (a[0, i] + a[1, i]) * t_step * 0.5 * (lambda[0, i] + lambda[1, i])
                            / (0.5 * (lambda[0, i] + lambda[1, i]) * hy_step * hy_step + (a[0, i] + a[1, i]) * t_step * (0.5 * (lambda[0, i] + lambda[1, i]) + alpha_UpSide[i] * hy_step));
                        beta_y[0, i] = (0.5 * (lambda[0, i] + lambda[1, i]) * hy_step * hy_step * T2[0, i] + (a[0, i] + a[1, i]) * t_step * alpha_UpSide[i] * hy_step * T_1 + hy_step * t_step * (a[0, i] + a[1, i]) * Qr_UpSide[i])
                            / (0.5 * (lambda[0, i] + lambda[1, i]) * hy_step * hy_step + (a[0, i] + a[1, i]) * t_step * (0.5 * (lambda[0, i] + lambda[1, i]) + alpha_UpSide[i] * hy_step));
                    }



                    // Аy, Вy, Сy, Fy
                    for (int i = 1; i <= Kx - 1; i++)
                    {
                        for (int j = 1; j <= Ky - 1; j++)
                        {
                            Ay[j, i] = -0.5 * (a[j, i] + a[j - 1, i]) * ry;
                            By[j, i] = 0.5 * ry * (a[j + 1, i] + 2 * a[j, i] + a[j - 1, i]) + 1;
                            Cy[j, i] = -0.5 * (a[j + 1, i] + a[j, i]) * ry;
                            Fy[j, i] = T1[j, i];
                        }
                    }

                    // Прогоночные коэффициенты 
                    for (int i = 1; i <= Kx - 1; i++)
                    {
                        for (int j = 1; j <= Ky - 1; j++)
                        {
                            alpha_y[j, i] = -Cy[j, i] / (Ay[j, i] * alpha_y[j - 1, i] + By[j, i]);
                            beta_y[j, i] = (Fy[j, i] - Ay[j, i] * beta_y[j - 1, i]) / (Ay[j, i] * alpha_y[j - 1, i] + By[j, i]);
                        }
                    }




                    // Температуры в Кy-ых точках
                    for (int i = 1; i <= Kx - 1; i++)
                    {
                        T2[Ky, i] = ((a[Ky, i] + a[Ky - 1, i]) * t_step * (hy_step * (alpha_DownSide[i] * T_0 + Qr_DownSide[i]) + 0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * beta_y[Ky - 1, i]) + 0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * hy_step * hy_step * T2[Ky, i])
                            / (0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * hy_step * hy_step + (a[Ky, i] + a[Ky - 1, i]) * t_step * (0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * (1 - alpha_y[Ky - 1, i]) + alpha_DownSide[i] * hy_step));
                    }



                    // Температуры во внутренних точках
                    for (int i = 1; i <= Kx - 1; i++)
                    {
                        for (int j = Ky - 1; j >= 0; j--)
                        {
                            T2[j, i] = alpha_y[j, i] * T2[j + 1, i] + beta_y[j, i];
                        }
                    }



                    // Граничное условие при (верхняя граница) 
                    for (int j = 0; j <= Ky - 1; j++)
                    {
                        T2[j, 0] = ((a[j, 0] + a[j, 1]) * t_step * 0.5 * (lambda[j, 1] + lambda[j, 0]) * T2[j, 1] + hx_step * hx_step * 0.5 * (lambda[j, 0] + lambda[j, 1]) * T[j, 0] + (a[j, 0] + a[j, 1]) * t_step * alpha_LeftSide[j] * hx_step * T_1 + hx_step * t_step * (a[j, 0] + a[j, 1]) * Qr_UpSide[j])
                            / (hx_step * hx_step * 0.5 * (lambda[j, 0] + lambda[j, 1]) + (a[j, 0] + a[j, 1]) * t_step * (0.5 * (lambda[j, 0] + lambda[j, 1]) + alpha_LeftSide[j] * hx_step));
                    }


                    // Угловая точка
                    T2[Ky, 0] = T2[Ky - 1, 0];


                    // Граничное условие при (нижняя граница)
                    for (int j = 1; j <= Ky / 2; j++)
                    {
                        T2[j, Kx] = ((a[j, Kx] + a[j, Kx - 1]) * t_step * (hx_step * (alpha_RightSide[j] * T_0 + Qr_RightSide[j]) + 0.5 * (lambda[j, Kx - 1] + lambda[j, Kx]) * T2[j, Kx - 1]) + hx_step * hx_step * 0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) * T1[j, Kx])
                            / (hx_step * hx_step * 0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) + (a[j, Kx] + a[j, Kx - 1]) * t_step * (0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) + alpha_RightSide[j] * hx_step));
                    }


                    // Угловая точка
                    T2[0, Kx] = T2[0, Kx - 1];


                    time += t_step;
                }







                // Левая и верняя стороны нагреты
                if (Quadrantleftsidecheck.Checked && Quadrantupsidecheck.Checked && !Quadrantrightsidecheck.Checked && !Quadrantdownsidecheck.Checked)

                {
                    for (int j = 0; j <= Ky; j += 1)
                    {
                        for (int i = 0; i <= Kx; i += 1)
                        {
                            T[j, i] = Math.Round(T2[j, i]);
                        }
                    }
                }



                // Левая и нижняя стороны нагреты
                if (Quadrantdownsidecheck.Checked && Quadrantleftsidecheck.Checked && !Quadrantupsidecheck.Checked && !Quadrantrightsidecheck.Checked)

                {
                    for (int j = 0; j <= Ky; j += 1)
                    {
                        for (int i = 0; i <= Kx; i += 1)
                        {
                            T[j, i] = Math.Round(T2[Ky - j, i]);
                        }
                    }
                }



                // Правая и нижняя стороны нагреты
                if (Quadrantrightsidecheck.Checked && Quadrantdownsidecheck.Checked && !Quadrantupsidecheck.Checked && !Quadrantleftsidecheck.Checked)
                {
                    for (int j = 0; j <= Ky; j += 1)
                    {
                        for (int i = 0; i <= Kx; i += 1)
                        {
                            T[j, i] = Math.Round(T2[Ky - j, Kx - i]);
                        }
                    }
                }



                // Правая и верхняя стороны нагреты
                if (Quadrantupsidecheck.Checked && Quadrantrightsidecheck.Checked && !Quadrantleftsidecheck.Checked && !Quadrantdownsidecheck.Checked)
                {
                    for (int j = 0; j <= Ky; j += 1)
                    {
                        for (int i = 0; i <= Kx; i += 1)
                        {
                            T[j, i] = Math.Round(T2[j, Kx - i]);
                        }
                    }
                }
            }

            // Нагрев с 2 противоположных сторон
            if (Quadrantleftsidecheck.Checked && Quadrantrightsidecheck.Checked && !Quadrantupsidecheck.Checked && !Quadrantdownsidecheck.Checked
                || Quadrantupsidecheck.Checked && Quadrantdownsidecheck.Checked && !Quadrantleftsidecheck.Checked && !Quadrantrightsidecheck.Checked)

                // Основной цикл
                while (time <= t_T)
                {

                    T_1 = 345 * Math.Log10(8 * time / 60 + 1) + T_0; // time = [мин]





                    for (int j = Ky / 2; j <= Ky; j++)
                    {
                        alpha_LeftSide[j] = 29.0;
                    }

                    for (int i = 0; i <= Kx / 2; i++)
                    {
                        alpha_DownSide[i] = 1.5 * Math.Pow(Math.Round(T1[Ky, i] - 20), 1.0 / 3.0);
                    }



                    for (int j = Ky / 2; j <= Ky; j++)
                    {
                        Qr_LeftSide[j] = 5.67 * epsilon_heat * (Math.Pow(0.01 * T_1 + 2.73, 4) - Math.Pow(0.01 * T1[j, 0] + 2.73, 4));
                    }

                    for (int i = 0; i <= Kx / 2; i++)
                    {
                        Qr_DownSide[i] = 5.67 * epsilon_cooling * (Math.Pow(0.01 * T_0 + 2.73, 4) - Math.Pow(0.01 * T1[Ky, i] + 2.73, 4));
                    }



                    // Коэффициенты теплоёмкости и теплопроводности в каждом точке
                    for (int j = Ky / 2; j <= Ky; j++)
                    {
                        for (int i = 0; i <= Kx / 2; i++)
                        {
                            lambda[j, i] = l1 - l2 * T2[j, i];
                            c[j, i] = (c1 + c2 * T2[j, i]) * 1000;
                        }
                    }



                    // Коэффициент температуропроводности в каждой точке
                    for (int j = Ky / 2; j <= Ky; j++)
                    {
                        for (int i = 0; i <= Kx / 2; i++)
                        {
                            a[j, i] = lambda[j, i] / (c[j, i] + 50 * W) / ro;
                        }
                    }


                    // Прогоночные к-ты для нулевой точки = const
                    for (int j = Ky / 2 + 1; j <= Ky - 1; j++)
                    {
                        alpha_x[j, 0] = (a[j, 0] + a[j, 1]) * t_step * 0.5 * (lambda[j, 0] + lambda[j, 1])
                            / (0.5 * (lambda[j, 0] + lambda[j, 1]) * hx_step * hx_step + (a[j, 0] + a[j, 1]) * t_step * (0.5 * (lambda[j, 0] + lambda[j, 1]) + alpha_LeftSide[j] * hx_step));
                        beta_x[j, 0] = (0.5 * (lambda[j, 0] + lambda[j, 1]) * hx_step * hx_step * T1[j, 0] + (a[j, 0] + a[j, 1]) * t_step * alpha_LeftSide[j] * hx_step * T_1 + hx_step * t_step * (a[j, 0] + a[j, 1]) * Qr_LeftSide[j])
                            / (0.5 * (lambda[j, 0] + lambda[j, 1]) * hx_step * hx_step + (a[j, 0] + a[j, 1]) * t_step * (0.5 * (lambda[j, 0] + lambda[j, 1]) + alpha_LeftSide[j] * hx_step));
                    }




                    // Аk, Вk, Сk, Fk
                    for (int j = Ky / 2 + 1; j <= Ky - 1; j++)
                    {
                        for (int i = 1; i <= Kx / 2 - 1; i++)
                        {
                            Ax[j, i] = -0.5 * (a[j, i] + a[j, i - 1]) * rx;
                            Bx[j, i] = 0.5 * rx * (a[j, i + 1] + 2 * a[j, i] + a[j, i - 1]) + 1;
                            Cx[j, i] = -0.5 * (a[j, i + 1] + a[j, i]) * rx;
                            Fx[j, i] = T[j, i];
                        }
                    }




                    // Прогоночные коэффициенты 
                    for (int j = Ky / 2 + 1; j <= Ky - 1; j++)
                    {
                        for (int i = 1; i <= Kx / 2 - 1; i++)
                        {
                            alpha_x[j, i] = -Cx[j, i] / (Ax[j, i] * alpha_x[j, i - 1] + Bx[j, i]);
                            beta_x[j, i] = (Fx[j, i] - Ax[j, i] * beta_x[j, i - 1]) / (Ax[j, i] * alpha_x[j, i - 1] + Bx[j, i]);
                        }
                    }



                    // Б/р температура в К-той точке
                    for (int j = Ky / 2 + 1; j <= Ky - 1; j++)
                    {
                        T1[j, Kx / 2] = ((a[j, Kx / 2] + a[j, Kx / 2 - 1]) * t_step * beta_x[j, Kx / 2 - 1] + hx_step * hx_step * T1[j, Kx / 2]) / (hx_step * hx_step + (a[j, Kx / 2] + a[j, Kx / 2 - 1]) * t_step * (1 - alpha_x[j, Kx / 2 - 1]));

                    }



                    // Б/р температуры в 0...К-1 точках 
                    for (int j = Ky / 2 + 1; j <= Ky - 1; j++)
                    {
                        for (int i = Kx / 2 - 1; i >= 0; i--)
                        {
                            T1[j, i] = alpha_x[j, i] * T1[j, i + 1] + beta_x[j, i];
                        }
                    }




                    // Граничное условие при y = 0 
                    for (int i = 0; i <= Kx / 2; i++)
                    {
                        T1[Ky / 2, i] = T1[Ky / 2 + 1, i];
                    }




                    // Граничное условие при y = H/2
                    for (int i = 1; i <= Kx / 2; i++)
                    {
                        T1[Ky, i] = ((a[Ky, i] + a[Ky - 1, i]) * t_step * (hy_step * (alpha_DownSide[i] * T_0 + Qr_DownSide[i]) + 0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * T1[Ky - 1, i]) + 0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * hy_step * hy_step * T1[Ky, i])
                            / ((a[Ky, i] + a[Ky - 1, i]) * t_step * (0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) + alpha_DownSide[i] * hy_step) + 0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * hy_step * hy_step);
                    }



                    T1[Ky, 0] = T1[Ky - 1, 0];



                    // 2 этап


                    for (int i = 0; i <= Kx / 2; i++)
                    {
                        alpha_DownSide[i] = 1.5 * Math.Pow(Math.Round(T2[Ky, i] - 20), 1.0 / 3.0);
                    }



                    for (int j = Ky / 2; j <= Ky; j++)
                    {
                        Qr_LeftSide[j] = 5.67 * epsilon_heat * (Math.Pow(0.01 * T_1 + 2.73, 4) - Math.Pow(0.01 * T2[j, 0] + 2.73, 4));
                    }

                    for (int i = 0; i <= Kx / 2; i++)
                    {
                        Qr_DownSide[i] = 5.67 * epsilon_cooling * (Math.Pow(0.01 * T_0 + 2.73, 4) - Math.Pow(0.01 * T2[Ky, i] + 2.73, 4));
                    }



                    // Прогоночные к-ты для нулевой точки = const
                    for (int i = 1; i <= Kx / 2 - 1; i++)
                    {
                        alpha_y[Ky / 2, i] = (a[Ky / 2, i] + a[Ky / 2 + 1, i]) * t_step
                            / (hy_step * hy_step + (a[Ky / 2, i] + a[Ky / 2 + 1, i]) * t_step);
                        beta_y[Ky / 2, i] = hy_step * hy_step * T1[Ky / 2, i]
                            / (hy_step * hy_step + (a[Ky / 2, i] + a[Ky / 2 + 1, i]) * t_step);
                    }



                    // Аk, Вk, Сk, Fk
                    for (int i = 1; i <= Kx / 2 - 1; i++)
                    {
                        for (int j = Ky / 2 + 1; j <= Ky - 1; j++)
                        {
                            Ay[j, i] = -0.5 * (a[j, i] + a[j - 1, i]) * ry;
                            By[j, i] = 0.5 * ry * (a[j + 1, i] + 2 * a[j, i] + a[j - 1, i]) + 1;
                            Cy[j, i] = -0.5 * (a[j + 1, i] + a[j, i]) * ry;
                            Fy[j, i] = T1[j, i];
                        }
                    }

                    // Прогоночные коэффициенты 
                    for (int i = 1; i <= Kx / 2 - 1; i++)
                    {
                        for (int j = Ky / 2 + 1; j <= Ky - 1; j++)
                        {
                            alpha_y[j, i] = -Cy[j, i] / (Ay[j, i] * alpha_y[j - 1, i] + By[j, i]);
                            beta_y[j, i] = (Fy[j, i] - Ay[j, i] * beta_y[j - 1, i]) / (Ay[j, i] * alpha_y[j - 1, i] + By[j, i]);
                        }
                    }




                    for (int i = 1; i <= Kx - 1; i++)
                    {
                        T2[Ky, i] = ((a[Ky, i] + a[Ky - 1, i]) * t_step * (hy_step * (alpha_DownSide[i] * T_0 + Qr_DownSide[i]) + 0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * beta_y[Ky - 1, i]) + 0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * hy_step * hy_step * T2[Ky, i])
                            / (0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * hy_step * hy_step + (a[Ky, i] + a[Ky - 1, i]) * t_step * (0.5 * (lambda[Ky, i] + lambda[Ky - 1, i]) * (1 - alpha_y[Ky - 1, i]) + alpha_DownSide[i] * hy_step));
                    }




                    // Б/р температуры в 0...К-1 точках
                    for (int i = 1; i <= Kx - 1; i++)
                    {
                        for (int j = Ky - 1; j >= Ky / 2; j--)
                        {
                            T2[j, i] = alpha_y[j, i] * T2[j + 1, i] + beta_y[j, i];
                        }
                    }




                    // Граничное условие при x = 0 
                    for (int j = Ky / 2; j <= Ky - 1; j++)
                    {
                        T2[j, 0] = ((a[j, 0] + a[j, 1]) * t_step * 0.5 * (lambda[j, 1] + lambda[j, 0]) * T2[j, 1] + hx_step * hx_step * 0.5 * (lambda[j, 0] + lambda[j, 1]) * T2[j, 0] + (a[j, 0] + a[j, 1]) * t_step * alpha_LeftSide[j] * hx_step * T_1 + hx_step * t_step * (a[j, 0] + a[j, 1]) * Qr_LeftSide[j])
                            / (hx_step * hx_step * 0.5 * (lambda[j, 0] + lambda[j, 1]) + (a[j, 0] + a[j, 1]) * t_step * (0.5 * (lambda[j, 0] + lambda[j, 1]) + alpha_LeftSide[j] * hx_step));
                    }

                    T2[Ky, 0] = T2[Ky - 1, 0];



                    // Граничное условие при x = W
                    for (int j = Ky / 2; j <= Ky; j++)
                    {
                        T2[j, Kx / 2] = (T2[j, Kx / 2 - 1] + hx_step * hx_step * T1[j, Kx / 2] / (a[j, Kx / 2] + a[j, Kx / 2 - 1]) / t_step) / (1 + hx_step * hx_step / (a[j, Kx / 2] + a[j, Kx / 2 - 1]) / t_step);

                    }

                    time += t_step;
                }


            // Левая и правая стороны нагреты
            if (Quadrantleftsidecheck.Checked && Quadrantrightsidecheck.Checked && !Quadrantupsidecheck.Checked && !Quadrantdownsidecheck.Checked)

            {

                // 3 четверть    
                for (int j = Ky / 2; j <= Ky; j++)
                {
                    for (int i = 0; i <= Kx / 2; i++)
                    {
                        T[j, i] = Math.Round(T2[j, i]);
                    }
                }

                // 4 четверть
                for (int j = Ky / 2; j <= Ky; j++)
                {
                    for (int i = Kx; i >= Kx / 2; i--)
                    {
                        T[j, i] = Math.Round(T2[j, Kx - i]);
                    }
                }

                // 1 и 2 четверти
                for (int j = 0; j <= Ky / 2; j++)
                {
                    for (int i = 0; i <= Kx; i++)
                    {
                        T[j, i] = T[Ky - j, i];
                    }
                }
            }

            // Верхняя и нижняя стороны нагреты

            if (Quadrantupsidecheck.Checked && Quadrantdownsidecheck.Checked && !Quadrantleftsidecheck.Checked && !Quadrantrightsidecheck.Checked)
            {

                // 1 четверть
                for (int j = 0; j <= Ky / 2; j++)
                {
                    for (int i = Kx / 2; i <= Kx; i++)
                    {
                        T[j, i] = Math.Round(T2[i, j]);
                    }
                }

                // 2 четверть
                for (int j = 0; j <= Ky / 2; j++)
                {
                    for (int i = 0; i <= Kx / 2; i++)
                    {
                        T[j, i] = T[j, Kx - i];
                    }
                }

                // 3 и 4 четверти
                for (int j = Ky / 2; j <= Ky; j++)
                {
                    for (int i = 0; i <= Kx; i++)
                    {
                        T[j, i] = T[Ky - j, i];
                    }
                }
            }


            // Нагрев с 3 сторон
            if (Quadrantleftsidecheck.Checked && Quadrantupsidecheck.Checked && Quadrantrightsidecheck.Checked && !Quadrantdownsidecheck.Checked
                || Quadrantupsidecheck.Checked && Quadrantrightsidecheck.Checked && Quadrantdownsidecheck.Checked && !Quadrantleftsidecheck.Checked
                || Quadrantleftsidecheck.Checked && Quadrantdownsidecheck.Checked && Quadrantrightsidecheck.Checked && !Quadrantupsidecheck.Checked
                || Quadrantupsidecheck.Checked && Quadrantleftsidecheck.Checked && Quadrantdownsidecheck.Checked && !Quadrantrightsidecheck.Checked)
                
                // Основной цикл
                while (time <= t_T)
                {

                    T_1 = 345 * Math.Log10(8 * time / 60 + 1) + T_0; // time = [мин]


                    for (int j = 0; j <= Ky / 2; j++)
                    {
                        alpha_LeftSide[j] = 29.0;
                    }

                    for (int j = 0; j <= Ky / 2; j++)
                    {
                        alpha_RightSide[j] = 1.5 * Math.Pow(Math.Round(T1[j, Kx] - 20), 1.0 / 3.0);
                    }

                    for (int i = 0; i <= Kx; i++)
                    {
                        alpha_UpSide[i] = 29.0;
                    }



                    for (int j = 0; j <= Ky / 2; j++)
                    {
                        Qr_LeftSide[j] = 5.67 * epsilon_heat * (Math.Pow(0.01 * T_1 + 2.73, 4) - Math.Pow(0.01 * T1[j, 0] + 2.73, 4));
                    }

                    for (int j = 0; j <= Ky / 2; j++)
                    {
                        Qr_RightSide[j] = 5.67 * epsilon_cooling * (Math.Pow(0.01 * T_0 + 2.73, 4) - Math.Pow(0.01 * T1[j, Kx] + 2.73, 4));
                    }

                    for (int i = 0; i <= Kx; i++)
                    {
                        Qr_UpSide[i] = 5.67 * epsilon_heat * (Math.Pow(0.01 * T_1 + 2.73, 4) - Math.Pow(0.01 * T1[0, i] + 2.73, 4));
                    }



                    // Коэффициенты теплоёмкости и теплопроводности в каждом точке
                    for (int j = 0; j <= Ky / 2; j++)
                    {
                        for (int i = 0; i <= Kx; i++)
                        {
                            lambda[j, i] = l1 - l2 * T2[j, i];
                            c[j, i] = (c1 + c2 * T2[j, i]) * 1000;
                        }
                    }



                    // Коэффициент температуропроводности в каждой точке
                    for (int j = 0; j <= Ky / 2; j++)
                    {
                        for (int i = 0; i <= Kx; i++)
                        {
                            a[j, i] = lambda[j, i] / (c[j, i] + 50 * W) / ro;
                        }
                    }



                    // Прогоночные к-ты для нулевой точки = const
                    for (int j = 1; j <= Ky / 2 - 1; j++)
                    {
                        alpha_x[j, 0] = (a[j, 0] + a[j, 1]) * t_step * 0.5 * (lambda[j, 0] + lambda[j, 1])
                            / (0.5 * (lambda[j, 0] + lambda[j, 1]) * hx_step * hx_step + (a[j, 0] + a[j, 1]) * t_step * (0.5 * (lambda[j, 0] + lambda[j, 1]) + alpha_LeftSide[j] * hx_step));
                        beta_x[j, 0] = (0.5 * (lambda[j, 0] + lambda[j, 1]) * hx_step * hx_step * T1[j, 0] + (a[j, 0] + a[j, 1]) * t_step * alpha_LeftSide[j] * hx_step * T_1 + hx_step * t_step * (a[j, 0] + a[j, 1]) * Qr_LeftSide[j])
                            / (0.5 * (lambda[j, 0] + lambda[j, 1]) * hx_step * hx_step + (a[j, 0] + a[j, 1]) * t_step * (0.5 * (lambda[j, 0] + lambda[j, 1]) + alpha_LeftSide[j] * hx_step));
                    }




                    // Аk, Вk, Сk, Fk
                    for (int j = 1; j <= Ky / 2 - 1; j++)
                    {
                        for (int i = 1; i <= Kx - 1; i++)
                        {
                            Ax[j, i] = -0.5 * (a[j, i] + a[j, i - 1]) * rx;
                            Bx[j, i] = 0.5 * rx * (a[j, i + 1] + 2 * a[j, i] + a[j, i - 1]) + 1;
                            Cx[j, i] = -0.5 * (a[j, i + 1] + a[j, i]) * rx;
                            Fx[j, i] = T2[j, i];
                        }
                    }

                    // Прогоночные коэффициенты 
                    for (int j = 1; j <= Ky / 2 - 1; j++)
                    {
                        for (int i = 1; i <= Kx - 1; i++)
                        {
                            alpha_x[j, i] = -Cx[j, i] / (Ax[j, i] * alpha_x[j, i - 1] + Bx[j, i]);
                            beta_x[j, i] = (Fx[j, i] - Ax[j, i] * beta_x[j, i - 1]) / (Ax[j, i] * alpha_x[j, i - 1] + Bx[j, i]);
                        }
                    }



                    // Б/р температура в К-той точке
                    for (int j = 1; j <= Ky / 2 - 1; j++)
                    {
                        T1[j, Kx] = ((a[j, Kx] + a[j, Kx - 1]) * t_step * (hx_step * (alpha_RightSide[j] * T_0 + Qr_RightSide[j]) + 0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) * beta_x[j, Kx - 1]) + 0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) * hx_step * hx_step * T1[j, Kx])
                            / (0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) * hx_step * hx_step + (a[j, Kx] + a[j, Kx - 1]) * t_step * (0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) * (1 - alpha_x[j, Kx - 1]) + alpha_RightSide[j] * hx_step));
                    }




                    // Б/р температуры в 0...К-1 точках 
                    for (int j = 1; j <= Ky / 2 - 1; j++)
                    {
                        for (int i = Kx - 1; i >= 0; i--)
                        {
                            T1[j, i] = alpha_x[j, i] * T1[j, i + 1] + beta_x[j, i];
                        }
                    }




                    // Граничное условие при y = 0 
                    for (int i = 0; i <= Kx - 1; i++)
                    {
                        T1[0, i] = ((a[0, i] + a[1, i]) * t_step * 0.5 * (lambda[0, i] + lambda[1, i]) * T1[1, i] + hy_step * hy_step * 0.5 * (lambda[0, i] + lambda[1, i]) * T1[0, i] + alpha_UpSide[i] * hy_step * t_step * T_1 * (a[0, i] + a[1, i]) + hy_step * t_step * (a[0, i] + a[1, i]) * Qr_UpSide[i])
                            / (hy_step * hy_step * 0.5 * (lambda[0, i] + lambda[1, i]) + (a[0, i] + a[1, i]) * t_step * (0.5 * (lambda[0, i] + lambda[1, i]) + alpha_UpSide[i] * hy_step));
                    }

                    T1[0, Kx] = T1[0, Kx - 1];


                    // Граничное условие при y = H/2
                    for (int i = 0; i <= Kx; i++)
                    {
                        T1[Ky / 2, i] = (T1[Ky / 2 - 1, i] + hy_step * hy_step * T1[Ky / 2, i] / (a[Ky / 2, i] + a[Ky / 2 - 1, i]) / t_step)
                            / (1 + hy_step * hy_step / (a[Ky / 2, i] + a[Ky / 2 - 1, i]) / t_step);
                    }


                    // 2 этап


                    for (int j = 0; j <= Ky / 2; j++)
                    {
                        alpha_RightSide[j] = 1.5 * Math.Pow(Math.Round(T2[j, Kx] - 20), 1.0 / 3.0);
                    }



                    for (int j = 0; j <= Ky / 2; j++)
                    {
                        Qr_LeftSide[j] = 5.67 * epsilon_heat * (Math.Pow(0.01 * T_1 + 2.73, 4) - Math.Pow(0.01 * T2[j, 0] + 2.73, 4));
                    }

                    for (int j = 0; j <= Ky / 2; j++)
                    {
                        Qr_RightSide[j] = 5.67 * epsilon_cooling * (Math.Pow(0.01 * T_0 + 2.73, 4) - Math.Pow(0.01 * T2[j, Kx] + 2.73, 4));
                    }

                    for (int i = 0; i <= Kx; i++)
                    {
                        Qr_UpSide[i] = 5.67 * epsilon_heat * (Math.Pow(0.01 * T_1 + 2.73, 4) - Math.Pow(0.01 * T2[0, i] + 2.73, 4));
                    }



                    // Прогоночные к-ты для нулевой точки = const
                    for (int i = 1; i <= Kx - 1; i++)
                    {
                        alpha_y[0, i] = (a[0, i] + a[1, i]) * t_step * 0.5 * (lambda[0, i] + lambda[1, i])
                            / (0.5 * (lambda[0, i] + lambda[1, i]) * hy_step * hy_step + (a[0, i] + a[1, i]) * t_step * (0.5 * (lambda[0, i] + lambda[1, i]) + alpha_UpSide[i] * hy_step));
                        beta_y[0, i] = (0.5 * (lambda[0, i] + lambda[1, i]) * hy_step * hy_step * T2[0, i] + (a[0, i] + a[1, i]) * t_step * alpha_UpSide[i] * hy_step * T_1 + hy_step * t_step * (a[0, i] + a[1, i]) * Qr_UpSide[i])
                            / (0.5 * (lambda[0, i] + lambda[1, i]) * hy_step * hy_step + (a[0, i] + a[1, i]) * t_step * (0.5 * (lambda[0, i] + lambda[1, i]) + alpha_UpSide[i] * hy_step));
                    }



                    // Аk, Вk, Сk, Fk
                    for (int i = 1; i <= Kx - 1; i++)
                    {
                        for (int j = 1; j <= Ky / 2 - 1; j++)
                        {
                            Ay[j, i] = -0.5 * (a[j, i] + a[j - 1, i]) * ry;
                            By[j, i] = 0.5 * ry * (a[j + 1, i] + 2 * a[j, i] + a[j - 1, i]) + 1;
                            Cy[j, i] = -0.5 * (a[j + 1, i] + a[j, i]) * ry;
                            Fy[j, i] = T1[j, i];
                        }
                    }

                    // Прогоночные коэффициенты 
                    for (int i = 1; i <= Kx - 1; i++)
                    {
                        for (int j = 1; j <= Ky / 2 - 1; j++)
                        {
                            alpha_y[j, i] = -Cy[j, i] / (Ay[j, i] * alpha_y[j - 1, i] + By[j, i]);
                            beta_y[j, i] = (Fy[j, i] - Ay[j, i] * beta_y[j - 1, i]) / (Ay[j, i] * alpha_y[j - 1, i] + By[j, i]);
                        }
                    }




                    // Б/р температура в К-той точке
                    for (int i = 1; i <= Kx - 1; i++)
                    {
                        T2[Ky / 2, i] = ((a[Ky / 2, i] + a[Ky / 2 - 1, i]) * t_step * beta_y[Ky / 2 - 1, i] + hy_step * hy_step * T2[Ky / 2, i])
                            / (hy_step * hy_step + (a[Ky / 2, i] + a[Ky / 2 - 1, i]) * t_step * (1 - alpha_y[Ky / 2 - 1, i]));
                    }




                    // Б/р температуры в 0...К-1 точках
                    for (int i = 1; i <= Kx - 1; i++)
                    {
                        for (int j = Ky / 2 - 1; j >= 0; j--)
                        {
                            T2[j, i] = alpha_y[j, i] * T2[j + 1, i] + beta_y[j, i];
                        }
                    }



                    // Граничное условие при x = 0 
                    for (int j = 0; j <= Ky / 2; j++)
                    {
                        T2[j, 0] = ((a[j, 0] + a[j, 1]) * t_step * 0.5 * (lambda[j, 1] + lambda[j, 0]) * T[j, 1] + hx_step * hx_step * 0.5 * (lambda[j, 0] + lambda[j, 1]) * T2[j, 0] + (a[j, 0] + a[j, 1]) * t_step * alpha_LeftSide[j] * hx_step * T_1 + hx_step * t_step * (a[j, 0] + a[j, 1]) * Qr_UpSide[j])
                            / (hx_step * hx_step * 0.5 * (lambda[j, 0] + lambda[j, 1]) + (a[j, 0] + a[j, 1]) * t_step * (0.5 * (lambda[j, 0] + lambda[j, 1]) + alpha_LeftSide[j] * hx_step));
                    }




                    // Граничное условие при x = W
                    for (int j = 1; j <= Ky / 2; j++)
                    {
                        T2[j, Kx] = ((a[j, Kx] + a[j, Kx - 1]) * t_step * (hx_step * (alpha_RightSide[j] * T_0 + Qr_RightSide[j]) + 0.5 * (lambda[j, Kx - 1] + lambda[j, Kx]) * T1[j, Kx - 1]) + hx_step * hx_step * 0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) * T1[j, Kx])
                            / (hx_step * hx_step * 0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) + (a[j, Kx] + a[j, Kx - 1]) * t_step * (0.5 * (lambda[j, Kx] + lambda[j, Kx - 1]) + alpha_RightSide[j] * hx_step));
                    }

                    T2[0, Kx] = T2[0, Kx - 1];


                    time += t_step;
                }

            //Левая, верхняя и нижняя стороны нагреты
            if (Quadrantupsidecheck.Checked && Quadrantleftsidecheck.Checked && Quadrantdownsidecheck.Checked && !Quadrantrightsidecheck.Checked)
            {

                // 1  и 2 четверти
                for (int j = 0; j <= Ky / 2; j += 1)
                {
                    for (int i = 0; i <= Kx; i += 1)
                    {
                        T[j, i] = Math.Round(T2[j, i]);
                    }
                }

                //3 и 4 четверти
                for (int j = Ky; j >= Ky / 2; j -= 1)
                {
                    for (int i = 0; i <= Kx; i += 1)
                    {
                        T[j, i] = T[Ky - j, i];
                    }
                }
            }

            //Правая, верхняя и нижняя стороны нагреты
            if (Quadrantupsidecheck.Checked && Quadrantrightsidecheck.Checked && Quadrantdownsidecheck.Checked && !Quadrantleftsidecheck.Checked)
            {

                // 1  и 2 четверти
                for (int j = 0; j <= Ky / 2; j += 1)
                {
                    for (int i = Kx; i >= 0; i -= 1)
                    {
                        T[j, i] = Math.Round(T2[j, Kx - i]);
                    }
                }

                //3 и 4 четверти
                for (int j = Ky; j >= Ky / 2; j -= 1)
                {
                    for (int i = 0; i <= Kx; i += 1)
                    {
                        T[j, i] = T[Ky - j, i];
                    }
                }
            }


            //Левая, правая и верхняя стороны нагреты
            if (Quadrantleftsidecheck.Checked && Quadrantupsidecheck.Checked && Quadrantrightsidecheck.Checked && !Quadrantdownsidecheck.Checked)
            {

                // 1  и 4 четверти
                for (int j = 0; j <= Ky; j += 1)
                {
                    for (int i = Kx / 2; i <= Kx; i += 1)
                    {
                        T[j, i] = Math.Round(T2[Ky - i, j]);
                    }
                }

                //2 и 3 четверти
                for (int j = 0; j <= Ky; j += 1)
                {
                    for (int i = 0; i <= Kx / 2; i += 1)
                    {
                        T[j, i] = T[j, Kx - i];
                    }
                }
            }

            //Левая, правая и нижняя стороны нагреты
            if (Quadrantleftsidecheck.Checked && Quadrantdownsidecheck.Checked && Quadrantrightsidecheck.Checked && !Quadrantupsidecheck.Checked)
            {
                // 2  и 3 четверти
                for (int j = Ky; j >= 0; j -= 1)
                {
                    for (int i = 0; i <= Kx / 2; i += 1)
                    {
                        T[j, i] = Math.Round(T2[i, Ky - j]);
                    }
                }

                //1 и 4 четверти
                for (int j = 0; j <= Ky; j += 1)
                {
                    for (int i = Kx; i >= Kx / 2; i -= 1)
                    {
                        T[j, i] = T[j, Kx - i];
                    }
                }
            }

            // Нагрев с 4 сторон
            if (Quadrantleftsidecheck.Checked && Quadrantdownsidecheck.Checked && Quadrantrightsidecheck.Checked && Quadrantupsidecheck.Checked)
            {

                // Основной цикл
                while (time <= t_T)
                {

                    T_1 = 345 * Math.Log10(8 * time / 60 + 1) + T_0; // time = [мин]



                    for (int j = 0; j <= Ky / 2; j++)
                    {
                        alpha_LeftSide[j] = 29.0;
                    }

                    for (int i = 0; i <= Kx / 2; i++)
                    {
                        alpha_UpSide[i] = 29.0;
                    }



                    for (int j = 0; j <= Ky / 2; j++)
                    {
                        Qr_LeftSide[j] = 5.67 * epsilon_heat * (Math.Pow(0.01 * T_1 + 2.73, 4) - Math.Pow(0.01 * T2[j, 0] + 2.73, 4));
                    }

                    for (int i = 0; i <= Kx / 2; i++)
                    {
                        Qr_UpSide[i] = 5.67 * epsilon_heat * (Math.Pow(0.01 * T_1 + 2.73, 4) - Math.Pow(0.01 * T2[0, i] + 2.73, 4));
                    }




                    // Коэффициенты теплоёмкости и теплопроводности в каждом точке
                    for (int j = 0; j <= Ky / 2; j++)
                    {
                        for (int i = 0; i <= Kx / 2; i++)
                        {
                            lambda[j, i] = l1 - l2 * T2[j, i];
                            c[j, i] = (c1 + c2 * T2[j, i]) * 1000;
                        }
                    }



                    // Коэффициент температуропроводности в каждой точке
                    for (int j = 0; j <= Ky / 2; j++)
                    {
                        for (int i = 0; i <= Kx / 2; i++)
                        {
                            a[j, i] = lambda[j, i] / (c[j, i] + 50 * W) / ro;
                        }
                    }


                    // Прогоночные к-ты для нулевой точки = const
                    for (int j = 1; j <= Ky / 2 - 1; j++)
                    {
                        alpha_x[j, 0] = (a[j, 0] + a[j, 1]) * t_step * 0.5 * (lambda[j, 0] + lambda[j, 1])
                            / (0.5 * (lambda[j, 0] + lambda[j, 1]) * hx_step * hx_step + (a[j, 0] + a[j, 1]) * t_step * (0.5 * (lambda[j, 0] + lambda[j, 1]) + alpha_LeftSide[j] * hx_step));
                        beta_x[j, 0] = (0.5 * (lambda[j, 0] + lambda[j, 1]) * hx_step * hx_step * T1[j, 0] + (a[j, 0] + a[j, 1]) * t_step * alpha_LeftSide[j] * hx_step * T_1 + hx_step * t_step * (a[j, 0] + a[j, 1]) * Qr_LeftSide[j])
                            / (0.5 * (lambda[j, 0] + lambda[j, 1]) * hx_step * hx_step + (a[j, 0] + a[j, 1]) * t_step * (0.5 * (lambda[j, 0] + lambda[j, 1]) + alpha_LeftSide[j] * hx_step));
                    }




                    // Аk, Вk, Сk, Fk
                    for (int j = 1; j <= Ky / 2 - 1; j++)
                    {
                        for (int i = 1; i <= Kx / 2 - 1; i++)
                        {
                            Ax[j, i] = -0.5 * (a[j, i] + a[j, i - 1]) * rx;
                            Bx[j, i] = 0.5 * rx * (a[j, i + 1] + 2 * a[j, i] + a[j, i - 1]) + 1;
                            Cx[j, i] = -0.5 * (a[j, i + 1] + a[j, i]) * rx;
                            Fx[j, i] = T[j, i];
                        }
                    }




                    // Прогоночные коэффициенты 
                    for (int j = 1; j <= Ky / 2 - 1; j++)
                    {
                        for (int i = 1; i <= Kx / 2 - 1; i++)
                        {
                            alpha_x[j, i] = -Cx[j, i] / (Ax[j, i] * alpha_x[j, i - 1] + Bx[j, i]);
                            beta_x[j, i] = (Fx[j, i] - Ax[j, i] * beta_x[j, i - 1]) / (Ax[j, i] * alpha_x[j, i - 1] + Bx[j, i]);
                        }
                    }





                    for (int j = 1; j <= Ky / 2 - 1; j++)
                    {
                        T1[j, Kx / 2] = ((a[j, Kx / 2] + a[j, Kx / 2 - 1]) * t_step * beta_x[j, Kx / 2 - 1] + hx_step * hx_step * T1[j, Kx / 2]) / (hx_step * hx_step + (a[j, Kx / 2] + a[j, Kx / 2 - 1]) * t_step * (1 - alpha_x[j, Kx / 2 - 1]));
                    }




                    // Б/р температуры в 0...К-1 точках 
                    for (int j = 1; j <= Ky / 2 - 1; j++)
                    {
                        for (int i = Kx / 2 - 1; i >= 0; i--)
                        {
                            T1[j, i] = alpha_x[j, i] * T1[j, i + 1] + beta_x[j, i];
                        }
                    }




                    // Граничное условие при y = 0 
                    for (int i = 0; i <= Kx / 2; i++)
                    {
                        T1[0, i] = ((a[0, i] + a[1, i]) * t_step * 0.5 * (lambda[0, i] + lambda[1, i]) * T1[1, i] + hy_step * hy_step * 0.5 * (lambda[0, i] + lambda[1, i]) * T1[0, i] + alpha_UpSide[i] * hy_step * t_step * T_1 * (a[0, i] + a[1, i]) + hy_step * t_step * (a[0, i] + a[1, i]) * Qr_UpSide[i])
                            / (hy_step * hy_step * 0.5 * (lambda[0, i] + lambda[1, i]) + (a[0, i] + a[1, i]) * t_step * (0.5 * (lambda[0, i] + lambda[1, i]) + alpha_UpSide[i] * hy_step));
                    }




                    // Граничное условие при y = H/2
                    for (int i = 0; i <= Kx / 2; i++)
                    {
                        T1[Ky / 2, i] = (T1[Ky / 2 - 1, i] + hy_step * hy_step * T1[Ky / 2, i] / (a[Ky / 2, i] + a[Ky / 2 - 1, i]) / t_step)
                            / (1 + hy_step * hy_step / (a[Ky / 2, i] + a[Ky / 2 - 1, i]) / t_step);
                    }







                    // 2 этап




                    // Прогоночные к-ты для нулевой точки = const
                    for (int i = 1; i <= Kx / 2 - 1; i++)
                    {
                        alpha_y[0, i] = (a[0, i] + a[1, i]) * t_step * 0.5 * (lambda[0, i] + lambda[1, i])
                            / (0.5 * (lambda[0, i] + lambda[1, i]) * hy_step * hy_step + (a[0, i] + a[1, i]) * t_step * (0.5 * (lambda[0, i] + lambda[1, i]) + alpha_UpSide[i] * hy_step));
                        beta_y[0, i] = (0.5 * (lambda[0, i] + lambda[1, i]) * hy_step * hy_step * T2[0, i] + (a[0, i] + a[1, i]) * t_step * alpha_UpSide[i] * hy_step * T_1 + hy_step * t_step * (a[0, i] + a[1, i]) * Qr_UpSide[i])
                            / (0.5 * (lambda[0, i] + lambda[1, i]) * hy_step * hy_step + (a[0, i] + a[1, i]) * t_step * (0.5 * (lambda[0, i] + lambda[1, i]) + alpha_UpSide[i] * hy_step));
                    }



                    // Аk, Вk, Сk, Fk
                    for (int i = 1; i <= Kx / 2 - 1; i++)
                    {
                        for (int j = 1; j <= Ky / 2 - 1; j++)
                        {
                            Ay[j, i] = -0.5 * (a[j, i] + a[j - 1, i]) * ry;
                            By[j, i] = 0.5 * ry * (a[j + 1, i] + 2 * a[j, i] + a[j - 1, i]) + 1;
                            Cy[j, i] = -0.5 * (a[j + 1, i] + a[j, i]) * ry;
                            Fy[j, i] = T1[j, i];
                        }
                    }

                    // Прогоночные коэффициенты 
                    for (int i = 1; i <= Kx / 2 - 1; i++)
                    {
                        for (int j = 1; j <= Ky / 2 - 1; j++)
                        {
                            alpha_y[j, i] = -Cy[j, i] / (Ay[j, i] * alpha_y[j - 1, i] + By[j, i]);
                            beta_y[j, i] = (Fy[j, i] - Ay[j, i] * beta_y[j - 1, i]) / (Ay[j, i] * alpha_y[j - 1, i] + By[j, i]);
                        }
                    }





                    // Б/р температура в К-той точке
                    for (int i = 1; i <= Kx / 2 - 1; i++)
                    {
                        T2[Ky / 2, i] = ((a[Ky / 2, i] + a[Ky / 2 - 1, i]) * t_step * beta_y[Ky / 2 - 1, i] + hy_step * hy_step * T2[Ky / 2, i])
                            / (hy_step * hy_step + (a[Ky / 2, i] + a[Ky / 2 - 1, i]) * t_step * (1 - alpha_y[Ky / 2 - 1, i]));
                    }




                    // Б/р температуры в 0...К-1 точках
                    for (int i = 1; i <= Kx / 2 - 1; i++)
                    {
                        for (int j = Ky / 2 - 1; j >= 0; j--)
                        {
                            T2[j, i] = alpha_y[j, i] * T2[j + 1, i] + beta_y[j, i];
                        }
                    }




                    // Граничное условие при x = 0 
                    for (int j = 0; j <= Ky / 2; j++)
                    {
                        T2[j, 0] = ((a[j, 0] + a[j, 1]) * t_step * 0.5 * (lambda[j, 1] + lambda[j, 0]) * T[j, 1] + hx_step * hx_step * 0.5 * (lambda[j, 0] + lambda[j, 1]) * T2[j, 0] + (a[j, 0] + a[j, 1]) * t_step * alpha_LeftSide[j] * hx_step * T_1 + hx_step * t_step * (a[j, 0] + a[j, 1]) * Qr_LeftSide[j])
                            / (hx_step * hx_step * 0.5 * (lambda[j, 0] + lambda[j, 1]) + (a[j, 0] + a[j, 1]) * t_step * (0.5 * (lambda[j, 0] + lambda[j, 1]) + alpha_LeftSide[j] * hx_step));
                    }





                    // Граничное условие при x = W
                    for (int j = 0; j <= Ky / 2; j++)
                    {
                        T2[j, Kx / 2] = (T2[j, Kx / 2 - 1] + hx_step * hx_step * T1[j, Kx / 2] / (a[j, Kx / 2] + a[j, Kx / 2 - 1]) / t_step) / (1 + hx_step * hx_step / (a[j, Kx / 2] + a[j, Kx / 2 - 1]) / t_step);
                    }

                    time += t_step;
                }




                // 2 четверть
                for (int j = 0; j <= Ky / 2; j++)
                {
                    for (int i = 0; i <= Kx / 2; i++)
                    {
                        T[j, i] = Math.Round(T2[j, Kx - i]);
                    }
                }




                // 1 четверть
                for (int j = 0; j <= Ky / 2; j++)
                {
                    for (int i = Kx; i >= Kx / 2; i--)
                    {
                        T[j, i] = Math.Round(T2[j, Kx - i]);
                    }
                }




                // 3 и 4 четверть
                for (int j = Ky; j >= Ky / 2; j--)
                {
                    for (int i = 0; i <= Kx; i++)
                    {
                        T[j, i] = T[Ky - j, i];
                    }
                }
            }



            if (File.Exists("outt.txt")) File.Delete("outt.txt");
            File.Create("outt.txt").Dispose();
            if (File.Exists("outx.txt")) File.Delete("outx.txt");
            File.Create("outx.txt").Dispose();
            if (File.Exists("outy.txt")) File.Delete("outy.txt");
            File.Create("outy.txt").Dispose();
            using (StreamWriter sw = File.AppendText("outt.txt")) 
            {
                foreach (double t in T) sw.Write(t + "  ");
            }
            using (StreamWriter sw = File.AppendText("outx.txt"))
            {
                foreach (double x in X) sw.Write(x + "  ");
            }
            using (StreamWriter sw = File.AppendText("outy.txt"))
            {
                foreach (double y in Y) sw.Write(y + "  ");
            }

        }

        public Form1()
        {
            InitializeComponent();
            if (flag_struct) RSU_panel.Visible = true;
            fire_resist_checkbox.Checked = fire_resistance;
            fire_safety_checkbox.Checked = fire_safety;
            
        }

        private void Armaturecombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Armaturecombobox.SelectedIndex == 0) { A600choice.Visible = false; A700choice.Visible = false; label_arm.Visible = true; A500choice.Visible = true; }
            if (Armaturecombobox.SelectedIndex == 1) { A500choice.Visible = false; A700choice.Visible = false; label_arm.Visible = true; A600choice.Visible = true; }
            if (Armaturecombobox.SelectedIndex == 2) { A500choice.Visible = false; A600choice.Visible = false;  label_arm.Visible = true; A700choice.Visible = true; }
            //if (tavr) label6.Visible = true, panel1.visible = true. if quadrant label7.visible = true, panel2.visible = true. пункт 6
        }

        private void parametersbut_Click(object sender, EventArgs e)
        {
            if (!panelparameters.Visible) panelparameters.Visible = true;
            else panelparameters.Visible = false;
        }

        private void Calculatebutton_Click(object sender, EventArgs e)
        {
            PCalculate();
        }

        private void acceptinputbutton_Click(object sender, EventArgs e)
        {
            t_T = (double)t_TNUD.Value; // Длительность пожара

            height = (double)HeightNUD.Value; // Высота сечения

            width = (double)WeightNUD.Value; // Ширина сечения

            T_0 = (double)T_0NUD.Value; // Начальная температура

            ro = (double)betonRoNUD.Value ; // Плотность бетона

            W = (double)WvalueNUD.Value ; // Влажность бетона
        }
    }
}
